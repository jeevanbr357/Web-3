// This is a simple script to run the frontend separately
const { execSync } = require('child_process');

console.log('Starting frontend development server...');
try {
  // Run the Vite dev server directly
  execSync('npx vite', { stdio: 'inherit' });
} catch (error) {
  console.error('Failed to start frontend:', error);
}
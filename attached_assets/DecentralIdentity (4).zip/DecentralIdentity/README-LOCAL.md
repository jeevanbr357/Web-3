# Running the Decentralized Identity Project Locally

This guide provides instructions for running the project locally with Node.js v22+, which has some compatibility issues with certain dependencies.

## Running the Project

### Option 1: Use Node.js LTS (Recommended)

The most reliable approach is to use Node.js LTS (v18):

1. Install Node.js v18:
   ```
   # Using nvm (recommended)
   nvm install 18
   nvm use 18
   
   # Or download from nodejs.org
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

### Option 2: Split Frontend and Backend (For Node.js v22+)

If you want to continue using Node.js v22, you can run the frontend and backend separately:

1. Install dependencies:
   ```
   npm install
   ```

2. Start the mock backend (in one terminal):
   ```
   # Using ts-node (you may need to install it first with npm install -g ts-node)
   ts-node server/local.ts
   
   # Or using node if you have TypeScript installed
   node --loader ts-node/esm server/local.ts
   ```

3. Start the frontend (in another terminal):
   ```
   node client.js
   ```

4. Access the application:
   - Frontend: http://localhost:5173
   - API: http://localhost:5000/api

## Troubleshooting

### IPFS HTTP Client Issues

If you encounter IPFS HTTP client issues, the project includes a mock implementation:

1. In your code that imports from 'server/lib/ipfs', change the import to use the mock version:
   ```typescript
   // Change this:
   import * as ipfs from './lib/ipfs';
   
   // To this:
   import * as ipfs from './lib/ipfs-mock';
   ```

### Express Router Issues

For Express router issues, ensure you're using a compatible Node.js version (v18 LTS) or modify the server code to be more compatible with ESM in Node.js v22+.

## Development Notes

- The ShareDocumentModal.tsx component has been enhanced with tabbed sharing options (Direct, Link, Email)
- For testing document upload functionality, use the simplified mock API
- When running separately, API calls from the frontend to the backend will go to http://localhost:5000/api/
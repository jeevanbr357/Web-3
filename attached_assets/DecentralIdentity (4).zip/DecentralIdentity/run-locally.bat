@echo off
echo Decentralized Identity Project - Local Development

echo Checking Node.js version...
node -v

echo.
echo Choose an option:
echo 1. Run with Node.js v18 (Recommended - requires Node v18 installed)
echo 2. Run backend only (compatible with Node.js v22)
echo 3. Run frontend only
echo 4. Exit
echo.

set /p option=Enter option (1-4): 

if "%option%"=="1" (
    echo Running with Node.js v18...
    echo Make sure you have Node.js v18 installed and active
    npm install
    npm run dev
) else if "%option%"=="2" (
    echo Running backend only...
    npx ts-node server/local.ts
) else if "%option%"=="3" (
    echo Running frontend only...
    node client.js
) else if "%option%"=="4" (
    echo Exiting...
    exit /b 0
) else (
    echo Invalid option. Please try again.
    exit /b 1
)
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/contexts/WalletContext";
import { Loader2 } from "lucide-react";
import { useState } from "react";
import exodusLogoPath from "../../assets/exodus-logo.svg";

interface WalletConnectionModalProps {
  isOpen: boolean;
}

export default function WalletConnectionModal({ isOpen }: WalletConnectionModalProps) {
  const { connectWallet, isConnecting } = useWallet();
  const [connectingExodus, setConnectingExodus] = useState(false);

  const handleConnect = async () => {
    setConnectingExodus(true);
    try {
      await connectWallet();
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setConnectingExodus(false);
    }
  };

  return (
    <Dialog open={isOpen} modal={true}>
      <DialogContent className="sm:max-w-md p-0">
        <div className="p-6 text-center">
          <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <img
              src={exodusLogoPath}
              alt="Exodus Wallet"
              className="h-16 w-16"
            />
          </div>
          <h3 className="text-xl font-semibold mb-2">Connect Your Wallet</h3>
          <p className="text-neutral-600 mb-6">
            Connect your Exodus wallet to create or access your decentralized identity
          </p>
          
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full px-4 py-6 justify-between hover:bg-neutral-100"
              onClick={handleConnect}
              disabled={isConnecting || connectingExodus}
            >
              <div className="flex items-center">
                <img
                  src={exodusLogoPath}
                  alt="Exodus Wallet"
                  className="h-8 w-8 mr-3"
                />
                <span className="font-medium">Exodus Wallet</span>
              </div>
              {connectingExodus ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <i className="fa-solid fa-chevron-right text-neutral-400"></i>
              )}
            </Button>
            
            <Button
              variant="outline"
              className="w-full px-4 py-6 justify-between opacity-50 cursor-not-allowed"
              disabled={true}
            >
              <div className="flex items-center">
                <i className="fa-brands fa-ethereum h-6 w-6 mr-3 text-center"></i>
                <span className="font-medium">Other Ethereum Wallet</span>
              </div>
              <span className="text-xs bg-neutral-200 text-neutral-600 px-2 py-0.5 rounded">
                Coming Soon
              </span>
            </Button>
          </div>
          
          <div className="mt-6 text-xs text-neutral-500">
            By connecting your wallet, you agree to our{" "}
            <a href="#" className="text-primary-500">Terms of Service</a> and{" "}
            <a href="#" className="text-primary-500">Privacy Policy</a>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

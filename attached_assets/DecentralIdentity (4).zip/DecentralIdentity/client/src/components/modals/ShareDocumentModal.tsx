import { useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogFooter, DialogHeader, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useDocument } from "@/contexts/DocumentContext";
import { Document, ACCESS_LEVELS, ACCESS_DURATIONS } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Copy, Check, Link as LinkIcon, Mail, Users } from "lucide-react";

interface ShareDocumentModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: Document;
}

export default function ShareDocumentModal({ isOpen, onClose, document }: ShareDocumentModalProps) {
  const { shareDocument } = useDocument();
  const { toast } = useToast();
  
  const [recipientDid, setRecipientDid] = useState("");
  const [accessLevel, setAccessLevel] = useState(ACCESS_LEVELS.VIEW_ONLY);
  const [accessDuration, setAccessDuration] = useState(ACCESS_DURATIONS[0]);
  const [message, setMessage] = useState("");
  const [isSharing, setIsSharing] = useState(false);
  const [generatedLink, setGeneratedLink] = useState("");
  const [isLinkCopied, setIsLinkCopied] = useState(false);
  const [activeTab, setActiveTab] = useState("direct");

  const handleSubmit = async () => {
    if (!recipientDid) {
      toast({
        title: "Missing information",
        description: "Please provide a recipient DID or wallet address",
        variant: "destructive"
      });
      return;
    }

    setIsSharing(true);
    
    try {
      await shareDocument({
        documentId: document.id,
        recipientDid,
        accessLevel,
        accessDuration,
        message
      });
      
      toast({
        title: "Document shared",
        description: "Your document has been successfully shared"
      });
      
      // Reset form
      setRecipientDid("");
      setAccessLevel(ACCESS_LEVELS.VIEW_ONLY);
      setAccessDuration(ACCESS_DURATIONS[0]);
      setMessage("");
      
      // Close modal
      onClose();
    } catch (error) {
      toast({
        title: "Sharing failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsSharing(false);
    }
  };
  
  // Generate a secure share link for the document
  const generateSecureLink = () => {
    setIsSharing(true);
    
    // Simulate link generation (in a real app, this would call an API)
    setTimeout(() => {
      // Generate a secure token with the document ID, access level, and expiration
      const token = `${document.id}_${accessLevel}_${Date.now()}`;
      const encodedToken = btoa(token);
      
      // Generate the link with the token
      const shareLink = `${window.location.origin}/shared/${encodedToken}`;
      setGeneratedLink(shareLink);
      setIsSharing(false);
      
      toast({
        title: "Link generated",
        description: "Secure document link has been created"
      });
    }, 1000);
  };
  
  // Copy the generated link to clipboard
  const copyLinkToClipboard = () => {
    if (!generatedLink) return;
    
    navigator.clipboard.writeText(generatedLink)
      .then(() => {
        setIsLinkCopied(true);
        toast({
          title: "Link copied",
          description: "Secure link copied to clipboard"
        });
        
        // Reset the copied state after 2 seconds
        setTimeout(() => {
          setIsLinkCopied(false);
        }, 2000);
      })
      .catch(() => {
        toast({
          title: "Copy failed",
          description: "Failed to copy link to clipboard",
          variant: "destructive"
        });
      });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">Share Document</DialogTitle>
          <DialogDescription>
            Share "{document.title}" securely with others
          </DialogDescription>
        </DialogHeader>
        
        <div className="mb-4">
          <div className="flex items-center text-xs text-neutral-500">
            {document.isEncrypted && (
              <div className="bg-emerald-100 text-emerald-600 rounded px-2 py-0.5 mr-2">
                <i className="fa-solid fa-lock mr-1"></i> Encrypted
              </div>
            )}
            {document.isNft && (
              <div className="bg-secondary-100 text-secondary-500 rounded px-2 py-0.5">
                <i className="fa-solid fa-certificate mr-1"></i> NFT Verified
              </div>
            )}
          </div>
        </div>
        
        <Tabs 
          defaultValue="direct" 
          className="w-full" 
          onValueChange={(value) => setActiveTab(value)}
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="direct" className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>Direct</span>
            </TabsTrigger>
            <TabsTrigger value="link" className="flex items-center gap-1">
              <LinkIcon className="h-4 w-4" />
              <span>Link</span>
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center gap-1">
              <Mail className="h-4 w-4" />
              <span>Email</span>
            </TabsTrigger>
          </TabsList>
          
          {/* Direct Share Tab */}
          <TabsContent value="direct" className="space-y-4 py-2">
            <div className="space-y-1">
              <Label htmlFor="recipient">Recipient's DID or Wallet Address</Label>
              <Input 
                id="recipient" 
                placeholder="did:eth:0x..." 
                value={recipientDid}
                onChange={(e) => setRecipientDid(e.target.value)}
              />
            </div>
            
            <div className="space-y-1">
              <Label>Access Level</Label>
              <RadioGroup 
                value={accessLevel} 
                onValueChange={setAccessLevel} 
                className="grid grid-cols-2 gap-3"
              >
                <div className={`border rounded-md p-3 cursor-pointer ${accessLevel === ACCESS_LEVELS.VIEW_ONLY ? 'border-primary-500 bg-primary-50' : ''}`}>
                  <div className="flex items-center">
                    <RadioGroupItem value={ACCESS_LEVELS.VIEW_ONLY} id="view-only" className="mr-2" />
                    <div>
                      <Label htmlFor="view-only" className="text-sm font-medium">View Only</Label>
                      <p className="text-xs text-neutral-500">Cannot download or reshare</p>
                    </div>
                  </div>
                </div>
                <div className={`border rounded-md p-3 cursor-pointer ${accessLevel === ACCESS_LEVELS.FULL_ACCESS ? 'border-primary-500 bg-primary-50' : ''}`}>
                  <div className="flex items-center">
                    <RadioGroupItem value={ACCESS_LEVELS.FULL_ACCESS} id="full-access" className="mr-2" />
                    <div>
                      <Label htmlFor="full-access" className="text-sm font-medium">Full Access</Label>
                      <p className="text-xs text-neutral-500">Can download and reshare</p>
                    </div>
                  </div>
                </div>
              </RadioGroup>
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="duration">Access Duration</Label>
              <Select value={accessDuration} onValueChange={setAccessDuration}>
                <SelectTrigger id="duration">
                  <SelectValue placeholder="Select access duration" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {ACCESS_DURATIONS.map((duration) => (
                      <SelectItem key={duration} value={duration}>{duration}</SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-1">
              <Label htmlFor="message">Additional Message (Optional)</Label>
              <Textarea 
                id="message" 
                placeholder="Add a note to the recipient" 
                rows={2}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
            </div>
            
            <div className="text-xs text-neutral-600">
              <i className="fa-solid fa-info-circle mr-1 text-primary-500"></i>
              Direct sharing creates a smart contract that grants access based on the selected criteria.
            </div>
          </TabsContent>
          
          {/* Link Share Tab */}
          <TabsContent value="link" className="space-y-4 py-2">
            <div className="text-sm text-neutral-600 mb-4">
              Create a secure link that can be shared with anyone. You control who can access this document.
            </div>
            
            <div className="space-y-3">
              <div className="space-y-1">
                <Label>Access Level</Label>
                <RadioGroup 
                  value={accessLevel} 
                  onValueChange={setAccessLevel} 
                  className="grid grid-cols-2 gap-3"
                >
                  <div className={`border rounded-md p-3 cursor-pointer ${accessLevel === ACCESS_LEVELS.VIEW_ONLY ? 'border-primary-500 bg-primary-50' : ''}`}>
                    <div className="flex items-center">
                      <RadioGroupItem value={ACCESS_LEVELS.VIEW_ONLY} id="link-view-only" className="mr-2" />
                      <div>
                        <Label htmlFor="link-view-only" className="text-sm font-medium">View Only</Label>
                        <p className="text-xs text-neutral-500">Cannot download</p>
                      </div>
                    </div>
                  </div>
                  <div className={`border rounded-md p-3 cursor-pointer ${accessLevel === ACCESS_LEVELS.FULL_ACCESS ? 'border-primary-500 bg-primary-50' : ''}`}>
                    <div className="flex items-center">
                      <RadioGroupItem value={ACCESS_LEVELS.FULL_ACCESS} id="link-full-access" className="mr-2" />
                      <div>
                        <Label htmlFor="link-full-access" className="text-sm font-medium">Full Access</Label>
                        <p className="text-xs text-neutral-500">Can download</p>
                      </div>
                    </div>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="link-duration">Link Expires</Label>
                <Select value={accessDuration} onValueChange={setAccessDuration}>
                  <SelectTrigger id="link-duration">
                    <SelectValue placeholder="Select expiration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {ACCESS_DURATIONS.map((duration) => (
                        <SelectItem key={duration} value={duration}>{duration}</SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              {!generatedLink ? (
                <Button 
                  className="w-full mt-2" 
                  onClick={generateSecureLink}
                  disabled={isSharing}
                >
                  {isSharing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <LinkIcon className="h-4 w-4 mr-2" />
                      Generate Secure Link
                    </>
                  )}
                </Button>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <Label htmlFor="share-link">Secure Link</Label>
                    <div className="flex">
                      <Input
                        id="share-link"
                        value={generatedLink}
                        readOnly
                        className="rounded-r-none"
                      />
                      <Button 
                        className="rounded-l-none flex-shrink-0" 
                        onClick={copyLinkToClipboard}
                      >
                        {isLinkCopied ? (
                          <Check className="h-4 w-4" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="text-xs text-neutral-500">
                      Expires: {accessDuration}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setGeneratedLink("")}
                    >
                      Reset
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          {/* Email Share Tab */}
          <TabsContent value="email" className="space-y-4 py-2">
            <div className="text-sm text-neutral-600 mb-4">
              Send an email with a secure link to access this document. Recipients will need to authenticate.
            </div>
            
            <div className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="email-recipient">Email Address</Label>
                <Input 
                  id="email-recipient" 
                  placeholder="recipient@example.com" 
                  type="email"
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="email-subject">Email Subject</Label>
                <Input 
                  id="email-subject" 
                  placeholder="Document shared with you" 
                  defaultValue={`${document.title} - Shared Document`}
                />
              </div>
              
              <div className="space-y-1">
                <Label htmlFor="email-message">Message</Label>
                <Textarea 
                  id="email-message" 
                  placeholder="I'm sharing this document with you..." 
                  rows={3}
                />
              </div>
              
              <Button className="w-full mt-2">
                <Mail className="h-4 w-4 mr-2" />
                Send Email
              </Button>
            </div>
          </TabsContent>
        </Tabs>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSharing}>
            Cancel
          </Button>
          
          {activeTab === "direct" && (
            <Button onClick={handleSubmit} disabled={isSharing || !recipientDid}>
              {isSharing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sharing...
                </>
              ) : (
                <>
                  <Users className="mr-2 h-4 w-4" />
                  Share Directly
                </>
              )}
            </Button>
          )}
          
          {activeTab === "link" && !generatedLink && (
            <Button onClick={generateSecureLink} disabled={isSharing}>
              {isSharing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <LinkIcon className="mr-2 h-4 w-4" />
                  Generate Link
                </>
              )}
            </Button>
          )}
          
          {activeTab === "link" && generatedLink && (
            <Button onClick={copyLinkToClipboard} disabled={isSharing}>
              {isLinkCopied ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Link
                </>
              )}
            </Button>
          )}
          
          {activeTab === "email" && (
            <Button disabled={isSharing}>
              <Mail className="mr-2 h-4 w-4" />
              Send Email
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

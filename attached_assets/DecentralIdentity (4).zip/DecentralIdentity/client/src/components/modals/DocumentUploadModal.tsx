import { useState } from "react";
import { Dialog, DialogTitle, DialogContent, DialogFooter, DialogHeader, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useDocument } from "@/contexts/DocumentContext";
import { useWallet } from "@/contexts/WalletContext";
import { DOCUMENT_TYPES } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { AlertCircle, Loader2, Upload } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface DocumentUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DocumentUploadModal({ isOpen, onClose }: DocumentUploadModalProps) {
  const { uploadDocument } = useDocument();
  const { isConnected } = useWallet();
  const { toast } = useToast();
  
  const [title, setTitle] = useState("");
  const [type, setType] = useState(DOCUMENT_TYPES[0]);
  const [file, setFile] = useState<File | null>(null);
  const [encrypt, setEncrypt] = useState(true);
  const [mintAsNft, setMintAsNft] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const handleSubmit = async () => {
    if (!title || !type || !file) {
      toast({
        title: "Missing information",
        description: "Please provide all required information",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    try {
      await uploadDocument({
        title,
        type,
        file,
        encrypt,
        mintAsNft
      });
      
      toast({
        title: "Document uploaded",
        description: "Your document has been securely uploaded"
      });
      
      // Reset form
      setTitle("");
      setType(DOCUMENT_TYPES[0]);
      setFile(null);
      setEncrypt(true);
      setMintAsNft(false);
      
      // Close modal
      onClose();
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.size > 25 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Maximum file size is 25MB",
          variant: "destructive"
        });
        return;
      }
      setFile(droppedFile);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      if (selectedFile.size > 25 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Maximum file size is 25MB",
          variant: "destructive"
        });
        return;
      }
      setFile(selectedFile);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">Upload Secure Document</DialogTitle>
          <DialogDescription>
            Upload your documents securely to the platform
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          {!isConnected && (
            <Alert className="bg-amber-50 border-amber-200">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertTitle className="text-amber-800">Anonymous Upload Mode</AlertTitle>
              <AlertDescription className="text-amber-700 text-sm">
                You're not connected with a wallet. You can still upload documents, but you'll need to connect 
                your wallet to access them later or mint them as NFTs.
              </AlertDescription>
            </Alert>
          )}
          <div className="space-y-1">
            <Label htmlFor="title">Document Title</Label>
            <Input 
              id="title" 
              placeholder="Enter document title" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>
          
          <div className="space-y-1">
            <Label htmlFor="type">Document Type</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger id="type">
                <SelectValue placeholder="Select document type" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {DOCUMENT_TYPES.map((docType) => (
                    <SelectItem key={docType} value={docType}>{docType}</SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-1">
            <Label>Upload File</Label>
            <div 
              className={`border-2 border-dashed ${isDragging ? 'border-primary-500 bg-primary-50' : 'border-neutral-300'} rounded-md p-6 text-center hover:bg-neutral-50 cursor-pointer`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('file-input')?.click()}
            >
              {file ? (
                <div className="flex items-center justify-center flex-col">
                  <div className="bg-primary-100 text-primary-600 p-2 rounded-full mb-2">
                    <i className="fa-solid fa-file text-xl"></i>
                  </div>
                  <p className="text-sm text-neutral-800 font-medium">{file.name}</p>
                  <p className="text-xs text-neutral-500 mt-1">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                </div>
              ) : (
                <>
                  <i className="fa-solid fa-cloud-arrow-up text-neutral-400 text-2xl mb-2"></i>
                  <p className="text-sm text-neutral-600">
                    Drag and drop your file here, or <span className="text-primary-600">browse</span>
                  </p>
                  <p className="text-xs text-neutral-500 mt-1">Max file size: 25MB</p>
                </>
              )}
              <input 
                id="file-input"
                type="file" 
                className="hidden" 
                onChange={handleFileChange}
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="encrypt" 
              checked={encrypt} 
              onCheckedChange={(checked) => setEncrypt(checked === true)}
            />
            <Label htmlFor="encrypt" className="text-sm">Encrypt document</Label>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="mint-nft" 
                checked={mintAsNft && isConnected}
                disabled={!isConnected}
                onCheckedChange={(checked) => setMintAsNft(checked === true)}
              />
              <Label htmlFor="mint-nft" className="text-sm">
                Mint as NFT for ownership verification
                {!isConnected && <span className="text-amber-500 ml-2">(requires wallet connection)</span>}
              </Label>
            </div>
            {mintAsNft && !isConnected && (
              <p className="text-xs text-red-500 pl-6">
                Connect your wallet from the sidebar first to enable this option
              </p>
            )}
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isUploading}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isUploading}
            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-white shadow-md"
          >
            {isUploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Upload & Secure
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useEffect } from "react";
import { Document } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Maximize, Minimize } from "lucide-react";

interface DocumentViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: Document;
}

export default function DocumentViewerModal({
  isOpen,
  onClose,
  document,
}: DocumentViewerModalProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  // Reset loading states when dialog opens
  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      setLoadError(false);
    }
  }, [isOpen]);

  // Determine document type for rendering purposes
  const getDocumentType = () => {
    if (!document.ipfsCid) return "unknown";
    
    // Simplified type detection for demo purposes
    const extension = document.title.split('.').pop()?.toLowerCase();
    
    if (extension === 'pdf') return 'pdf';
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(extension || '')) return 'image';
    if (['doc', 'docx', 'txt', 'md', 'csv', 'json'].includes(extension || '')) return 'text';
    
    // If we can't determine by extension, try to infer from document type
    const docType = document.type.toLowerCase();
    if (docType.includes('image')) return 'image';
    if (docType.includes('text') || docType.includes('document')) return 'text';
    
    return 'unknown';
  };

  const docType = getDocumentType();
  
  const toggleFullscreen = () => setIsFullscreen(!isFullscreen);
  
  const handleDownload = () => {
    if (document.ipfsCid) {
      window.open(`/api/ipfs/${document.ipfsCid}`, '_blank');
    }
  };
  
  const renderDocumentContent = () => {
    if (!document.ipfsCid) {
      return (
        <div className="flex items-center justify-center h-full p-8 text-neutral-400">
          No content available
        </div>
      );
    }

    const url = `/api/ipfs/${document.ipfsCid}`;

    switch (docType) {
      case 'pdf':
        return (
          <div className="h-full flex items-center justify-center">
            {isLoading && <div className="text-neutral-500">Loading PDF...</div>}
            <iframe
              src={url}
              className={`w-full h-full border-0 ${isLoading ? 'hidden' : 'block'}`}
              title={document.title}
              onLoad={() => setIsLoading(false)}
              onError={() => {
                setIsLoading(false);
                setLoadError(true);
              }}
            />
            {loadError && (
              <div className="flex flex-col items-center justify-center p-8">
                <p className="text-neutral-600 mb-4">Unable to preview this document</p>
                <Button onClick={handleDownload} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download to view
                </Button>
              </div>
            )}
          </div>
        );
      case 'image':
        return (
          <div className="flex items-center justify-center h-full overflow-auto">
            {isLoading && <div className="text-neutral-500">Loading image...</div>}
            <img
              src={url}
              alt={document.title}
              className={`max-w-full max-h-full object-contain ${isLoading ? 'hidden' : 'block'}`}
              onLoad={() => setIsLoading(false)}
              onError={() => {
                setIsLoading(false);
                setLoadError(true);
              }}
            />
            {loadError && (
              <div className="flex flex-col items-center justify-center p-8">
                <p className="text-neutral-600 mb-4">Unable to preview this image</p>
                <Button onClick={handleDownload} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download to view
                </Button>
              </div>
            )}
          </div>
        );
      case 'text':
        return (
          <div className="h-full flex items-center justify-center">
            {isLoading && <div className="text-neutral-500">Loading content...</div>}
            <iframe
              src={url}
              className={`w-full h-full border-0 ${isLoading ? 'hidden' : 'block'}`}
              title={document.title}
              onLoad={() => setIsLoading(false)}
              onError={() => {
                setIsLoading(false);
                setLoadError(true);
              }}
            />
            {loadError && (
              <div className="flex flex-col items-center justify-center p-8">
                <p className="text-neutral-600 mb-4">Unable to preview this document</p>
                <Button onClick={handleDownload} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download to view
                </Button>
              </div>
            )}
          </div>
        );
      default:
        return (
          <div className="flex flex-col items-center justify-center h-full p-8">
            <p className="text-neutral-600 mb-4">Preview not available for this file type</p>
            <Button onClick={handleDownload} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Download to view
            </Button>
          </div>
        );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent
        className={`${
          isFullscreen ? "fixed inset-0 max-w-none m-0 rounded-none h-screen" : "max-w-3xl"
        } p-0 overflow-hidden`}
        aria-describedby="document-viewer-description"
      >
        <DialogHeader className="px-6 py-4 border-b flex-row justify-between items-center">
          <div>
            <DialogTitle>{document.title}</DialogTitle>
            <DialogDescription id="document-viewer-description">{document.type}</DialogDescription>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="icon" onClick={toggleFullscreen}>
              {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
            <Button variant="outline" size="icon" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className={`${isFullscreen ? "h-[calc(100vh-9rem)]" : "h-[60vh]"} bg-neutral-50`}>
          {renderDocumentContent()}
        </div>

        <DialogFooter className="p-4 border-t bg-white">
          <Button
            variant="outline"
            onClick={onClose}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
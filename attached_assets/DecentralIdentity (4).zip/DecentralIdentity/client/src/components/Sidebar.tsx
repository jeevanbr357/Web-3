import { Link, useLocation } from "wouter";
import { useWallet } from "@/contexts/WalletContext";
import { cn } from "@/lib/utils";
import exodusLogoPath from "../assets/exodus-logo.svg";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useWallet();

  const isActive = (path: string) => {
    return location === path;
  };

  const navItems = [
    { path: "/", icon: "fa-house-user", label: "Dashboard", section: "Main" },
    { path: "/documents", icon: "fa-file-shield", label: "My Documents", section: "Main" },
    { path: "/shared", icon: "fa-share-nodes", label: "Shared With Me", section: "Main" },
    { path: "/nfts", icon: "fa-coins", label: "My NFTs", section: "Main" },
    { path: "/identity", icon: "fa-id-card", label: "Identity (DID)", section: "Account" },
    { path: "/wallet", icon: "fa-wallet", label: "Wallet", section: "Account", isExodusWallet: true },
    { path: "/settings", icon: "fa-gear", label: "Settings", section: "Account" },
  ];

  const mainNavItems = navItems.filter(item => item.section === "Main");
  const accountNavItems = navItems.filter(item => item.section === "Account");

  const getNavLinkClasses = (isItemActive: boolean) => {
    return cn(
      "block px-3 py-2 rounded-md font-medium mb-1 transition-colors",
      isItemActive 
        ? "text-primary-700 bg-primary-50" 
        : "text-neutral-700 hover:bg-neutral-100"
    );
  };

  return (
    <aside className={cn("bg-white lg:w-64 shadow-md", className)}>
      {/* Logo Section */}
      <div className="p-4 border-b">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-primary-600 to-secondary-500 rounded-md flex items-center justify-center">
            <span className="text-white font-bold">S</span>
          </div>
          <span className="text-lg font-semibold">SecureID</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-2 flex-grow">
        <div className="py-2 px-3 text-xs font-semibold text-neutral-600 uppercase">Main</div>
        
        {mainNavItems.map(item => (
          <Link key={item.path} href={item.path}>
            <a className={getNavLinkClasses(isActive(item.path))}>
              <i className={`fa-solid ${item.icon} w-5 mr-2 text-center`}></i> {item.label}
            </a>
          </Link>
        ))}

        <div className="py-2 px-3 mt-4 text-xs font-semibold text-neutral-600 uppercase">Account</div>
        
        {accountNavItems.map(item => (
          <Link key={item.path} href={item.path}>
            <a className={getNavLinkClasses(isActive(item.path))}>
              {item.isExodusWallet ? (
                <img src={exodusLogoPath} alt="Exodus Wallet" className="w-5 h-5 mr-2" />
              ) : (
                <i className={`fa-solid ${item.icon} w-5 mr-2 text-center`}></i>
              )} 
              {item.label}
            </a>
          </Link>
        ))}
      </nav>

      {/* User Info */}
      {user && (
        <div className="p-4 border-t">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-neutral-200 flex items-center justify-center">
              <i className="fa-solid fa-user text-neutral-600"></i>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-neutral-800 truncate">
                {user.username || 'Anonymous User'}
              </p>
              <p className="text-xs text-neutral-500 truncate font-mono">
                {user.did ? `did:eth:${user.did.substring(0, 5)}...${user.did.substring(user.did.length - 4)}` : ''}
              </p>
            </div>
            <button className="text-neutral-400 hover:text-neutral-600">
              <i className="fa-solid fa-ellipsis-vertical"></i>
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}

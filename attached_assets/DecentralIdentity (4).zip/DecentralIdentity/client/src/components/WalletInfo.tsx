import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/contexts/WalletContext";
import { Button } from "@/components/ui/button";
import exodusLogoPath from "@/assets/exodus-logo.svg";

interface WalletInfoProps {
  onUploadClick: () => void;
}

export default function WalletInfo({ onUploadClick }: WalletInfoProps) {
  const { user } = useWallet();
  const { toast } = useToast();
  
  const handleCopyDid = () => {
    if (user?.did) {
      navigator.clipboard.writeText(user.did);
      toast({
        title: "DID Copied",
        description: "Decentralized ID copied to clipboard",
        duration: 3000,
      });
    }
  };

  if (!user) return null;

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold">Your Identity</h2>
          <div className="flex items-center mt-1">
            <span className="font-mono text-sm text-neutral-700 mr-2">{user.did}</span>
            <button 
              className="text-neutral-500 hover:text-primary-500" 
              onClick={handleCopyDid}
            >
              <i className="fa-regular fa-copy"></i>
            </button>
          </div>
          <div className="flex mt-2">
            <div className="flex items-center text-sm text-emerald-500 mr-4">
              <i className="fa-solid fa-circle-check mr-1"></i>
              <span>Verified</span>
            </div>
            <div className="flex items-center text-sm text-neutral-600">
              <img 
                src={exodusLogoPath} 
                alt="Exodus Wallet" 
                className="h-4 w-4 mr-1"
              />
              <span>Exodus Wallet</span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            className="px-4 py-2 bg-neutral-100 text-neutral-700 rounded-md hover:bg-neutral-200 text-sm font-medium"
          >
            <i className="fa-solid fa-id-card mr-1"></i> Manage DID
          </Button>
          <Button 
            variant="default" 
            className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 text-sm font-medium"
            onClick={onUploadClick}
          >
            <i className="fa-solid fa-upload mr-1"></i> Upload Document
          </Button>
        </div>
      </div>
    </div>
  );
}

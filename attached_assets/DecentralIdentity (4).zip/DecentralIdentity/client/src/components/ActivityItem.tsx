import { Activity, ACTIVITY_TYPES } from "@shared/schema";
import { formatDistanceToNow, format } from "date-fns";

interface ActivityItemProps {
  activity: Activity;
}

export default function ActivityItem({ activity }: ActivityItemProps) {
  const getActivityIcon = () => {
    switch (activity.activityType) {
      case ACTIVITY_TYPES.DOCUMENT_SHARE:
        return { icon: "fa-share-nodes", bgColor: "bg-primary-100", textColor: "text-primary-600" };
      case ACTIVITY_TYPES.DOCUMENT_NFT_MINT:
        return { icon: "fa-certificate", bgColor: "bg-secondary-100", textColor: "text-secondary-600" };
      case ACTIVITY_TYPES.DOCUMENT_UPLOAD:
        return { icon: "fa-upload", bgColor: "bg-emerald-100", textColor: "text-emerald-600" };
      case ACTIVITY_TYPES.WALLET_CONNECT:
      case ACTIVITY_TYPES.DID_CREATE:
        return { icon: "fa-key", bgColor: "bg-neutral-100", textColor: "text-neutral-600" };
      default:
        return { icon: "fa-circle-info", bgColor: "bg-neutral-100", textColor: "text-neutral-600" };
    }
  };

  const getActivityTitle = () => {
    const details = activity.details as any;
    
    switch (activity.activityType) {
      case ACTIVITY_TYPES.DOCUMENT_SHARE:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">{details?.title || "Document"}</span> shared with{" "}
            <span className="font-medium">{details?.recipientDid?.substring(0, 8)}...{details?.recipientDid?.substring(details?.recipientDid?.length - 4)}</span>
          </p>
        );
      case ACTIVITY_TYPES.DOCUMENT_NFT_MINT:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">{details?.title || "Document"}</span> minted as NFT
          </p>
        );
      case ACTIVITY_TYPES.DOCUMENT_UPLOAD:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">{details?.title || "Document"}</span> uploaded and {details?.isEncrypted ? "encrypted" : "stored"}
          </p>
        );
      case ACTIVITY_TYPES.WALLET_CONNECT:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">Wallet</span> connected successfully
          </p>
        );
      case ACTIVITY_TYPES.DID_CREATE:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">DID</span> successfully created
          </p>
        );
      default:
        return (
          <p className="text-sm text-neutral-800">
            <span className="font-medium">Unknown activity</span>
          </p>
        );
    }
  };

  const getActivitySubtitle = () => {
    const details = activity.details as any;
    
    switch (activity.activityType) {
      case ACTIVITY_TYPES.DOCUMENT_SHARE:
        return "Smart contract executed";
      case ACTIVITY_TYPES.DOCUMENT_NFT_MINT:
        return details?.tokenId ? `Transaction: ${details?.tokenId.substring(0, 4)}...${details?.tokenId.substring(details?.tokenId.length - 4)}` : "NFT minted successfully";
      case ACTIVITY_TYPES.DOCUMENT_UPLOAD:
        return details?.ipfsCid ? `IPFS CID: ${details?.ipfsCid.substring(0, 4)}...${details?.ipfsCid.substring(details?.ipfsCid.length - 4)}` : "Upload successful";
      case ACTIVITY_TYPES.WALLET_CONNECT:
      case ACTIVITY_TYPES.DID_CREATE:
        return details?.walletAddress ? `Wallet: ${details?.walletAddress.substring(0, 4)}...${details?.walletAddress.substring(details?.walletAddress.length - 4)}` : "Identity operation";
      default:
        return "";
    }
  };

  const formatActivityTime = () => {
    if (!activity.createdAt) return "";
    
    const date = new Date(activity.createdAt);
    const relativeTime = formatDistanceToNow(date, { addSuffix: true });
    const timeString = format(date, 'h:mm a');
    
    return `${relativeTime.charAt(0).toUpperCase() + relativeTime.slice(1)} • ${timeString}`;
  };

  const { icon, bgColor, textColor } = getActivityIcon();

  return (
    <div className="flex items-start space-x-3 pb-4 border-b border-neutral-100 last:border-0 last:pb-0">
      <div className={`${bgColor} ${textColor} p-2 rounded-full`}>
        <i className={`fa-solid ${icon}`}></i>
      </div>
      <div className="flex-1">
        {getActivityTitle()}
        <p className="text-xs text-neutral-500 mt-1">{formatActivityTime()} • {getActivitySubtitle()}</p>
      </div>
      <button className="p-1 text-neutral-500 hover:text-primary-500">
        <i className="fa-solid fa-ellipsis-vertical"></i>
      </button>
    </div>
  );
}

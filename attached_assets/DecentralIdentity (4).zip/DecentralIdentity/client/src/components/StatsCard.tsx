import { Skeleton } from "@/components/ui/skeleton";

interface StatsCardProps {
  title: string;
  count: number;
  icon: string;
  color: "primary" | "secondary" | "accent";
  change: {
    type: "increase" | "decrease" | "neutral";
    value: string;
    period: string;
  };
  loading?: boolean;
}

export default function StatsCard({ 
  title, 
  count, 
  icon, 
  color, 
  change, 
  loading = false 
}: StatsCardProps) {
  const getBgColor = () => {
    switch (color) {
      case "primary": return "bg-primary-100 text-primary-600";
      case "secondary": return "bg-secondary-100 text-secondary-500";
      case "accent": return "bg-emerald-100 text-emerald-600";
      default: return "bg-neutral-100 text-neutral-600";
    }
  };

  const getChangeColor = () => {
    switch (change.type) {
      case "increase": return "text-emerald-500";
      case "decrease": return "text-red-500";
      case "neutral": return "text-neutral-500";
      default: return "text-neutral-500";
    }
  };

  const getChangeIcon = () => {
    switch (change.type) {
      case "increase": return "fa-arrow-up";
      case "decrease": return "fa-arrow-down";
      default: return "";
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-600 text-sm">{title}</p>
          {loading ? (
            <Skeleton className="h-8 w-16 mt-1" />
          ) : (
            <p className="text-2xl font-semibold mt-1">{count}</p>
          )}
        </div>
        <div className={`p-2 rounded-md ${getBgColor()}`}>
          <i className={`fa-solid fa-${icon}`}></i>
        </div>
      </div>
      <div className="mt-2 text-xs text-neutral-500">
        {loading ? (
          <Skeleton className="h-4 w-28" />
        ) : (
          <>
            <span className={getChangeColor()}>
              {change.type !== "neutral" && <i className={`fa-solid ${getChangeIcon()} mr-1`}></i>}
              {change.value}
            </span>
            {change.period && ` ${change.period}`}
          </>
        )}
      </div>
    </div>
  );
}

import { Document } from "@shared/schema";
import { useState } from "react";
import { useDocument } from "@/contexts/DocumentContext";
import ShareDocumentModal from "./modals/ShareDocumentModal";
import DocumentViewerModal from "./modals/DocumentViewerModal";
import { Skeleton } from "@/components/ui/skeleton";
import { differenceInDays, format, formatDistanceToNow } from "date-fns";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { MoreVertical, Share, Download, Trash, Shield, Award, Eye } from "lucide-react";

interface DocumentCardProps {
  document: Document;
  viewMode: "grid" | "list";
}

export default function DocumentCard({ document, viewMode }: DocumentCardProps) {
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const { shareDocument } = useDocument();

  const getDocumentIcon = () => {
    switch (document.type) {
      case "Legal document":
        return "fa-file-contract";
      case "Financial document":
        return "fa-file-invoice-dollar";
      case "Health document":
        return "fa-file-medical";
      case "Intellectual property":
        return "fa-lightbulb";
      case "Personal ID":
        return "fa-id-card";
      default:
        return "fa-file-lines";
    }
  };

  const getUpdatedTimeText = () => {
    if (!document.updatedAt) return "N/A";
    
    const updatedDate = new Date(document.updatedAt);
    const daysDiff = differenceInDays(new Date(), updatedDate);
    
    if (daysDiff < 1) {
      return `Updated today at ${format(updatedDate, 'h:mm a')}`;
    } else if (daysDiff < 30) {
      return `Updated ${formatDistanceToNow(updatedDate, { addSuffix: true })}`;
    } else {
      return `Updated on ${format(updatedDate, 'MMM d, yyyy')}`;
    }
  };
  
  // If we're in grid mode, render the card view
  if (viewMode === "grid") {
    return (
      <>
        <div className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition">
          <div className="aspect-w-3 aspect-h-2 bg-neutral-100 relative cursor-pointer" onClick={() => setIsViewerOpen(true)}>
            {document.isNft && (
              <div className="absolute top-2 right-2 bg-secondary-500 text-white text-xs rounded-full px-2 py-1 shadow-sm">
                <i className="fa-solid fa-certificate mr-1"></i> NFT
              </div>
            )}
            <div className="flex items-center justify-center h-full">
              {document.ipfsCid ? (
                <img 
                  src={`/api/ipfs/${document.ipfsCid}`} 
                  className="object-cover w-full h-full" 
                  alt={document.title}
                  onError={(e) => {
                    // If image fails to load, fall back to an icon
                    e.currentTarget.style.display = 'none';
                    // Fix the document element access issue with proper DOM handling
                    setTimeout(() => {
                      const iconElement = window.document.getElementById(`doc-icon-${document.id}`);
                      if (iconElement) {
                        iconElement.style.display = 'block';
                      }
                    }, 0);
                  }}
                />
              ) : null}
              <i 
                id={`doc-icon-${document.id}`}
                className={`fa-regular ${getDocumentIcon()} text-neutral-400 text-4xl ${document.ipfsCid ? 'hidden' : ''}`}
              ></i>
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-30 opacity-0 hover:opacity-100 transition-opacity">
                <Eye className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
          <div className="p-4">
            <div className="flex justify-between items-start">
              <h3 className="font-medium text-neutral-800">{document.title}</h3>
              {document.isEncrypted && (
                <div className="text-xs bg-emerald-100 text-emerald-600 rounded px-2 py-0.5">
                  Encrypted
                </div>
              )}
            </div>
            <p className="text-sm text-neutral-600 mt-1">{document.type}</p>
            <div className="flex items-center mt-3 text-xs text-neutral-500">
              <i className="fa-regular fa-clock mr-1"></i>
              <span>{getUpdatedTimeText()}</span>
            </div>
            <div className="flex items-center justify-between mt-4">
              <div className="flex -space-x-2">
                {/* This would typically be populated with actual user data */}
                <div className="w-6 h-6 rounded-full bg-neutral-200 flex items-center justify-center border-2 border-white">
                  <i className="fa-solid fa-user text-neutral-500 text-xs"></i>
                </div>
              </div>
              <div className="flex space-x-1">
                <button 
                  className="p-1 text-neutral-500 hover:text-primary-500"
                  onClick={() => setIsShareModalOpen(true)}
                >
                  <Share className="h-4 w-4" />
                </button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="p-1 text-neutral-500 hover:text-primary-500 focus:outline-none">
                      <MoreVertical className="h-4 w-4" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={() => setIsViewerOpen(true)} className="cursor-pointer">
                      <Eye className="h-4 w-4 mr-2" />
                      <span>View Document</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setIsShareModalOpen(true)} className="cursor-pointer">
                      <Share className="h-4 w-4 mr-2" />
                      <span>Share Document</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="cursor-pointer" onClick={() => {
                      if (document.ipfsCid) {
                        window.open(`/api/ipfs/${document.ipfsCid}`, '_blank');
                      }
                    }}>
                      <Download className="h-4 w-4 mr-2" />
                      <span>Download</span>
                    </DropdownMenuItem>
                    {!document.isNft && (
                      <DropdownMenuItem className="cursor-pointer">
                        <Award className="h-4 w-4 mr-2" />
                        <span>Mint as NFT</span>
                      </DropdownMenuItem>
                    )}
                    {!document.isEncrypted && (
                      <DropdownMenuItem className="cursor-pointer">
                        <Shield className="h-4 w-4 mr-2" />
                        <span>Encrypt</span>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem className="cursor-pointer text-red-600">
                      <Trash className="h-4 w-4 mr-2" />
                      <span>Delete</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </div>

        <ShareDocumentModal 
          isOpen={isShareModalOpen} 
          onClose={() => setIsShareModalOpen(false)} 
          document={document}
        />
        <DocumentViewerModal
          isOpen={isViewerOpen}
          onClose={() => setIsViewerOpen(false)}
          document={document}
        />
      </>
    );
  }

  // Otherwise, render the list view
  return (
    <>
      <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 cursor-pointer" onClick={() => setIsViewerOpen(true)}>
            <div className={`p-2 rounded-md bg-neutral-100 text-neutral-600`}>
              <i className={`fa-regular ${getDocumentIcon()}`}></i>
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <h3 className="font-medium text-neutral-800 truncate">{document.title}</h3>
                {document.isNft && (
                  <div className="text-xs bg-secondary-100 text-secondary-500 rounded px-2 py-0.5">
                    NFT
                  </div>
                )}
                {document.isEncrypted && (
                  <div className="text-xs bg-emerald-100 text-emerald-600 rounded px-2 py-0.5">
                    Encrypted
                  </div>
                )}
              </div>
              <p className="text-sm text-neutral-600">{document.type}</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-xs text-neutral-500 hidden md:block">
              <i className="fa-regular fa-clock mr-1"></i>
              <span>{getUpdatedTimeText()}</span>
            </div>
            <div className="flex space-x-1">
              <button 
                className="p-1 text-neutral-500 hover:text-primary-500"
                onClick={() => setIsShareModalOpen(true)}
              >
                <Share className="h-4 w-4" />
              </button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="p-1 text-neutral-500 hover:text-primary-500 focus:outline-none">
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => setIsViewerOpen(true)} className="cursor-pointer">
                    <Eye className="h-4 w-4 mr-2" />
                    <span>View Document</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setIsShareModalOpen(true)} className="cursor-pointer">
                    <Share className="h-4 w-4 mr-2" />
                    <span>Share Document</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer" onClick={() => {
                    if (document.ipfsCid) {
                      window.open(`/api/ipfs/${document.ipfsCid}`, '_blank');
                    }
                  }}>
                    <Download className="h-4 w-4 mr-2" />
                    <span>Download</span>
                  </DropdownMenuItem>
                  {!document.isNft && (
                    <DropdownMenuItem className="cursor-pointer">
                      <Award className="h-4 w-4 mr-2" />
                      <span>Mint as NFT</span>
                    </DropdownMenuItem>
                  )}
                  {!document.isEncrypted && (
                    <DropdownMenuItem className="cursor-pointer">
                      <Shield className="h-4 w-4 mr-2" />
                      <span>Encrypt</span>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem className="cursor-pointer text-red-600">
                    <Trash className="h-4 w-4 mr-2" />
                    <span>Delete</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      <ShareDocumentModal 
        isOpen={isShareModalOpen} 
        onClose={() => setIsShareModalOpen(false)} 
        document={document}
      />
      <DocumentViewerModal
        isOpen={isViewerOpen}
        onClose={() => setIsViewerOpen(false)}
        document={document}
      />
    </>
  );
}

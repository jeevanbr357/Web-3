import { useWallet } from "@/contexts/WalletContext";
import { Button } from "@/components/ui/button";
import { Bell, Upload } from "lucide-react";
import { useLocation } from "wouter";
import exodusLogoPath from "../assets/exodus-logo.svg";

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const { isConnected } = useWallet();
  const [location, setLocation] = useLocation();

  // Function to handle document upload button click
  const handleUploadClick = () => {
    // Navigate to Documents page and open the upload modal
    if (location !== "/documents") {
      setLocation("/documents");
    }
    
    // Set a flag in sessionStorage to open the upload modal
    // The Documents page will check for this flag
    sessionStorage.setItem("openUploadModal", "true");
  };

  return (
    <header className="sticky top-0 z-10 bg-white border-b shadow-sm">
      <div className="flex justify-between items-center px-4 py-3">
        <div className="flex items-center lg:hidden">
          <button 
            type="button" 
            className="text-neutral-700 hover:text-primary-500"
            onClick={onMenuClick}
          >
            <i className="fa-solid fa-bars"></i>
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Upload Button - Always visible */}
          <Button 
            onClick={handleUploadClick}
            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-white shadow-md"
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload Document
          </Button>
        </div>
        
        <div className="flex items-center space-x-4">
          {isConnected && (
            <>
              <div className="relative">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="relative text-neutral-600 hover:text-primary-500"
                >
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-primary-500"></span>
                </Button>
              </div>
              
              <div className="flex items-center">
                <div className="bg-neutral-100 rounded-full py-1 px-3 flex items-center">
                  <img
                    src={exodusLogoPath}
                    alt="Exodus Wallet"
                    className="h-5 w-5 mr-2"
                  />
                  <span className="text-xs font-medium text-neutral-700">Wallet Connected</span>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

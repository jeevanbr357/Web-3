import React, { useState } from "react";
import Sidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import { useWallet } from "@/contexts/WalletContext";
import WalletConnectionModal from "@/components/modals/WalletConnectionModal";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const { isConnected } = useWallet();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  const toggleMobileSidebar = () => {
    setIsMobileSidebarOpen(!isMobileSidebarOpen);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Sidebar - hidden on mobile unless toggled */}
      <div className={`
        fixed inset-0 z-40 lg:relative lg:z-auto
        transition-transform duration-300 ease-in-out
        lg:transform-none lg:opacity-100
        ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        lg:block
      `}>
        <div 
          className="absolute inset-0 bg-neutral-800/70 lg:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
        <Sidebar className="relative z-10 lg:h-screen lg:sticky lg:top-0" />
      </div>

      {/* Main content */}
      <main className="flex-1">
        <Header onMenuClick={toggleMobileSidebar} />
        
        {/* Render children if wallet is connected, otherwise show connection modal */}
        {isConnected ? (
          children
        ) : (
          <div className="p-4">
            <WalletConnectionModal isOpen={true} />
          </div>
        )}
      </main>
    </div>
  );
}

import React, { createContext, useContext, useState, useEffect } from "react";
import { Document } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "./WalletContext";
import { queryClient } from "@/lib/queryClient";

interface UploadDocumentParams {
  title: string;
  type: string;
  file: File;
  encrypt: boolean;
  mintAsNft: boolean;
}

interface ShareDocumentParams {
  documentId: number;
  recipientDid: string;
  accessLevel: string;
  accessDuration: string;
  message?: string;
}

interface DocumentContextType {
  documents: Document[];
  isLoading: boolean;
  uploadDocument: (params: UploadDocumentParams) => Promise<void>;
  shareDocument: (params: ShareDocumentParams) => Promise<void>;
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export const DocumentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { isConnected } = useWallet();

  // Fetch documents when user is connected
  useEffect(() => {
    if (isConnected) {
      fetchDocuments();
    } else {
      setDocuments([]);
    }
  }, [isConnected]);

  const fetchDocuments = async () => {
    // Only fetch documents if connected with a wallet
    if (!isConnected) return;
    
    setIsLoading(true);
    try {
      const response = await fetch("/api/documents", {
        credentials: "include"
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch documents");
      }
      
      const data = await response.json();
      setDocuments(data.documents || []);
    } catch (error) {
      console.error("Error fetching documents:", error);
      toast({
        title: "Error",
        description: "Failed to load documents",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const uploadDocument = async (params: UploadDocumentParams) => {
    const { title, type, file, encrypt, mintAsNft } = params;
    
    // Create form data
    const formData = new FormData();
    formData.append("title", title);
    formData.append("type", type);
    formData.append("file", file);
    formData.append("encrypt", encrypt.toString());
    formData.append("mintAsNft", mintAsNft.toString());
    
    try {
      // If minting as NFT but not connected, show error
      if (mintAsNft && !isConnected) {
        throw new Error("You must connect your wallet to mint an NFT");
      }
      
      const response = await fetch("/api/documents", {
        method: "POST",
        body: formData,
        credentials: "include"
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to upload document");
      }
      
      // Refresh documents list if user is connected
      if (isConnected) {
        await fetchDocuments();
        
        // Invalidate stats cache
        queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
        queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      }
      
      toast({
        title: "Success",
        description: "Document uploaded successfully" + (!isConnected ? ". Connect your wallet to access it later." : ""),
      });
      
      return await response.json();
    } catch (error) {
      console.error("Error uploading document:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to upload document",
        variant: "destructive"
      });
      throw error;
    }
  };

  const shareDocument = async (params: ShareDocumentParams) => {
    try {
      const response = await apiRequest("POST", `/api/documents/${params.documentId}/share`, params);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to share document");
      }
      
      // Invalidate stats & activities cache
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      
      return await response.json();
    } catch (error) {
      console.error("Error sharing document:", error);
      throw error;
    }
  };

  return (
    <DocumentContext.Provider
      value={{
        documents,
        isLoading,
        uploadDocument,
        shareDocument
      }}
    >
      {children}
    </DocumentContext.Provider>
  );
};

export const useDocument = () => {
  const context = useContext(DocumentContext);
  if (context === undefined) {
    throw new Error("useDocument must be used within a DocumentProvider");
  }
  return context;
};

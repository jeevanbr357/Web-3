import React, { createContext, useContext, useState, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { connectExodusWallet, disconnectWallet } from "@/lib/web3";
import { queryClient } from "@/lib/queryClient";

interface User {
  id: number;
  username: string;
  did: string;
  walletAddress: string;
}

interface WalletContextType {
  user: User | null;
  isConnected: boolean;
  isConnecting: boolean;
  connectWallet: () => Promise<void>;
  disconnect: () => Promise<void>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const { toast } = useToast();

  const checkAuthStatus = async () => {
    try {
      const res = await fetch("/api/auth/me", {
        credentials: "include"
      });
      
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      }
    } catch (error) {
      console.error("Failed to check auth status:", error);
    }
  };

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const connectWallet = async () => {
    setIsConnecting(true);
    
    try {
      // Connect to Exodus wallet
      const { address, signature } = await connectExodusWallet();
      
      // Send wallet data to the server
      const res = await apiRequest("POST", "/api/auth/connect-wallet", {
        walletAddress: address,
        signature: signature
      });
      
      const data = await res.json();
      setUser(data.user);
      
      toast({
        title: "Wallet Connected",
        description: "Your Exodus wallet has been successfully connected",
      });
      
      // Invalidate any cached data
      queryClient.invalidateQueries();
    } catch (error) {
      console.error("Failed to connect wallet:", error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Could not connect to wallet",
        variant: "destructive"
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnect = async () => {
    try {
      // Disconnect from wallet
      await disconnectWallet();
      
      // Clear session on server
      await apiRequest("POST", "/api/auth/disconnect", {});
      
      // Clear user state
      setUser(null);
      
      toast({
        title: "Disconnected",
        description: "Your wallet has been disconnected",
      });
      
      // Clear cached data
      queryClient.clear();
    } catch (error) {
      console.error("Failed to disconnect:", error);
      toast({
        title: "Disconnection Failed",
        description: "Could not disconnect from wallet",
        variant: "destructive"
      });
    }
  };

  return (
    <WalletContext.Provider
      value={{
        user,
        isConnected: !!user,
        isConnecting,
        connectWallet,
        disconnect
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
};

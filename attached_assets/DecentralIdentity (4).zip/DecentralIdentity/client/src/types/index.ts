// Web3 types
export interface WalletConnection {
  address: string;
  signature: string;
}

// Document types
export interface DocumentMetadata {
  title: string;
  description?: string;
  type: string;
  creator: string;
  createdAt: string;
  ipfsCid: string;
  encryptionKey?: string;
}

// NFT types
export interface NFTMetadata {
  tokenId: string;
  contractAddress: string;
  documentCid: string;
  owner: string;
  createdAt: string;
}

// DID types
export interface DIDDocument {
  id: string;
  controller: string[];
  verificationMethod: {
    id: string;
    type: string;
    controller: string;
    publicKeyMultibase: string;
  }[];
  authentication: string[];
}

// Smart contract types
export interface AccessControl {
  owner: string;
  documentId: string;
  accessList: {
    did: string;
    accessLevel: string;
    expiresAt: number;
  }[];
}

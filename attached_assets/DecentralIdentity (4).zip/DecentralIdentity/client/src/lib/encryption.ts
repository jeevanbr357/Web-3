/**
 * Generate encryption key pair
 */
export async function generateKeyPair(): Promise<CryptoKeyPair> {
  try {
    // Generate RSA key pair for encryption/decryption
    const keyPair = await window.crypto.subtle.generateKey(
      {
        name: "RSA-OAEP",
        modulusLength: 2048,
        publicExponent: new Uint8Array([1, 0, 1]),
        hash: "SHA-256"
      },
      true,
      ["encrypt", "decrypt"]
    );
    
    return keyPair;
  } catch (error) {
    console.error("Error generating key pair:", error);
    throw new Error("Failed to generate encryption keys");
  }
}

/**
 * Export public key as string
 * 
 * @param publicKey Public key to export
 */
export async function exportPublicKey(publicKey: CryptoKey): Promise<string> {
  try {
    const exported = await window.crypto.subtle.exportKey("spki", publicKey);
    const exportedAsString = arrayBufferToBase64(exported);
    return exportedAsString;
  } catch (error) {
    console.error("Error exporting public key:", error);
    throw new Error("Failed to export public key");
  }
}

/**
 * Import public key from string
 * 
 * @param publicKeyString Public key string
 */
export async function importPublicKey(publicKeyString: string): Promise<CryptoKey> {
  try {
    const binaryDer = base64ToArrayBuffer(publicKeyString);
    
    const publicKey = await window.crypto.subtle.importKey(
      "spki",
      binaryDer,
      {
        name: "RSA-OAEP",
        hash: "SHA-256"
      },
      true,
      ["encrypt"]
    );
    
    return publicKey;
  } catch (error) {
    console.error("Error importing public key:", error);
    throw new Error("Failed to import public key");
  }
}

/**
 * Encrypt data with public key
 * 
 * @param data Data to encrypt
 * @param publicKey Public key to use for encryption
 */
export async function encryptData(data: ArrayBuffer, publicKey: CryptoKey): Promise<ArrayBuffer> {
  try {
    const encrypted = await window.crypto.subtle.encrypt(
      {
        name: "RSA-OAEP"
      },
      publicKey,
      data
    );
    
    return encrypted;
  } catch (error) {
    console.error("Error encrypting data:", error);
    throw new Error("Failed to encrypt data");
  }
}

/**
 * Decrypt data with private key
 * 
 * @param encryptedData Encrypted data
 * @param privateKey Private key to use for decryption
 */
export async function decryptData(encryptedData: ArrayBuffer, privateKey: CryptoKey): Promise<ArrayBuffer> {
  try {
    const decrypted = await window.crypto.subtle.decrypt(
      {
        name: "RSA-OAEP"
      },
      privateKey,
      encryptedData
    );
    
    return decrypted;
  } catch (error) {
    console.error("Error decrypting data:", error);
    throw new Error("Failed to decrypt data");
  }
}

/**
 * Helper function to convert ArrayBuffer to Base64 string
 */
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

/**
 * Helper function to convert Base64 string to ArrayBuffer
 */
function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

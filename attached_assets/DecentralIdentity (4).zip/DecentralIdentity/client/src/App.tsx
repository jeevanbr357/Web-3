import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import MainLayout from "./layouts/MainLayout";
import Dashboard from "./pages/Dashboard";
import Documents from "./pages/Documents";
import SharedWithMe from "./pages/SharedWithMe";
import MyNFTs from "./pages/MyNFTs";
import Identity from "./pages/Identity";
import Wallet from "./pages/Wallet";
import Settings from "./pages/Settings";
import { WalletProvider } from "./contexts/WalletContext";
import { DocumentProvider } from "./contexts/DocumentContext";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/documents" component={Documents} />
      <Route path="/shared" component={SharedWithMe} />
      <Route path="/nfts" component={MyNFTs} />
      <Route path="/identity" component={Identity} />
      <Route path="/wallet" component={Wallet} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WalletProvider>
        <DocumentProvider>
          <MainLayout>
            <Router />
          </MainLayout>
          <Toaster />
        </DocumentProvider>
      </WalletProvider>
    </QueryClientProvider>
  );
}

export default App;

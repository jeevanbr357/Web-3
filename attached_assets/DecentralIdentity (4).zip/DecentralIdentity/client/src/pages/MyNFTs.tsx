import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import { useWallet } from "@/contexts/WalletContext";

interface NFT {
  id: number;
  title: string;
  type: string;
  tokenId: string;
  contractAddress: string;
  createdAt: string;
}

export default function MyNFTs() {
  const { user } = useWallet();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch NFTs
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/nfts"],
    enabled: !!user
  });
  
  const nfts: NFT[] = data?.nfts || [];
  
  // Filter NFTs based on search query
  const filteredNFTs = nfts.filter(nft => 
    nft.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    nft.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    nft.tokenId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">My NFTs</h1>
          <p className="text-neutral-600">Document ownership verified on the blockchain</p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder="Search NFTs..."
              className="px-3 py-2 rounded-md border border-neutral-300 text-sm w-full focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fa-solid fa-search absolute right-3 top-2.5 text-neutral-400"></i>
          </div>
        </div>
      </div>

      {/* NFTs list */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        </div>
      ) : error ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-red-500 text-4xl mb-3">
            <i className="fa-solid fa-circle-exclamation"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">Error Loading NFTs</h3>
          <p className="text-neutral-600 mb-4">Unable to load your document NFTs</p>
        </div>
      ) : filteredNFTs.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-neutral-400 text-4xl mb-3">
            <i className="fa-solid fa-certificate"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No NFTs Found</h3>
          <p className="text-neutral-600">You don't have any document NFTs yet. When uploading a document, select the "Mint as NFT" option.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNFTs.map((nft) => (
            <div key={nft.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition">
              <div className="border-b p-4 bg-gradient-to-r from-secondary-100 to-purple-50">
                <div className="flex justify-between items-start">
                  <h3 className="font-medium text-neutral-800">{nft.title}</h3>
                  <div className="bg-secondary-500 text-white text-xs rounded-full px-2 py-1">
                    <i className="fa-solid fa-certificate mr-1"></i> NFT
                  </div>
                </div>
                <p className="text-sm text-neutral-600 mt-1">{nft.type}</p>
              </div>
              
              <div className="p-4">
                <div className="mb-4">
                  <div className="text-xs text-neutral-500 mb-1">Token ID</div>
                  <div className="font-mono text-sm bg-neutral-100 p-2 rounded overflow-x-auto">
                    {nft.tokenId}
                  </div>
                </div>
                
                <div className="mb-4">
                  <div className="text-xs text-neutral-500 mb-1">Contract Address</div>
                  <div className="font-mono text-sm bg-neutral-100 p-2 rounded overflow-x-auto">
                    {nft.contractAddress}
                  </div>
                </div>
                
                <div className="flex justify-between items-center mt-3 text-xs text-neutral-500">
                  <div>
                    <i className="fa-regular fa-clock mr-1"></i>
                    <span>Minted on {new Date(nft.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex space-x-1">
                    <button className="p-1 text-neutral-500 hover:text-primary-500">
                      <i className="fa-solid fa-eye"></i>
                    </button>
                    <button className="p-1 text-neutral-500 hover:text-primary-500">
                      <i className="fa-solid fa-ellipsis-vertical"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clipboard, LogOut, RefreshCw } from "lucide-react";
import { useWallet } from "@/contexts/WalletContext";
import { useToast } from "@/hooks/use-toast";
import exodusLogoPath from "../assets/exodus-logo.svg";

export default function Wallet() {
  const { user, disconnect, isConnected } = useWallet();
  const { toast } = useToast();
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  const handleCopyWalletAddress = () => {
    if (user?.walletAddress) {
      navigator.clipboard.writeText(user.walletAddress);
      toast({
        title: "Wallet Address Copied",
        description: "Wallet address copied to clipboard",
      });
    }
  };
  
  const handleDisconnect = async () => {
    await disconnect();
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected successfully",
    });
  };
  
  const handleRefreshConnection = async () => {
    setIsRefreshing(true);
    try {
      // In a real implementation, we would refresh the connection with the wallet
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "Connection Refreshed",
        description: "Your wallet connection has been refreshed",
      });
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh wallet connection",
        variant: "destructive"
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  if (!isConnected) {
    return (
      <div className="p-4 lg:p-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-1">Wallet Connection</h1>
          <p className="text-neutral-600">Connect your Web3 wallet to access the platform</p>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="flex justify-center mb-3">
            <img 
              src={exodusLogoPath} 
              alt="Exodus Wallet" 
              className="h-16 w-16 opacity-40"
            />
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">Not Connected</h3>
          <p className="text-neutral-600 mb-4">Please connect your Exodus wallet to manage your documents</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Wallet Connection</h1>
        <p className="text-neutral-600">Manage your Web3 wallet connection</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-600">Wallet Type</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <img 
                src={exodusLogoPath} 
                alt="Exodus Wallet" 
                className="h-6 w-6 mr-2"
              />
              <span className="text-lg font-semibold">Exodus Wallet</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-600">Connection Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className="flex items-center bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></div>
                <span className="font-medium">Connected</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-neutral-600">Network</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <i className="fa-brands fa-ethereum h-6 w-6 mr-2 text-neutral-600"></i>
              <span className="text-lg font-semibold">Ethereum Mainnet</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Wallet Information</CardTitle>
          <CardDescription>Details of your connected cryptocurrency wallet</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Wallet Address</h4>
              <div className="bg-neutral-100 p-3 rounded-md flex items-center justify-between">
                <code className="font-mono text-sm break-all">{user?.walletAddress || ""}</code>
                <Button variant="ghost" size="sm" onClick={handleCopyWalletAddress}>
                  <Clipboard className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Connected DID</h4>
                <div className="bg-neutral-100 p-2 rounded-md text-sm font-mono overflow-hidden text-ellipsis">
                  {user?.did || ""}
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-1">Connected Since</h4>
                <div className="bg-neutral-100 p-2 rounded-md text-sm">
                  {new Date().toLocaleString()}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Connection Management</CardTitle>
          <CardDescription>Manage your wallet connection to the platform</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <Button variant="outline" className="flex-1" onClick={handleRefreshConnection} disabled={isRefreshing}>
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              {isRefreshing ? 'Refreshing...' : 'Refresh Connection'}
            </Button>
            
            <Button variant="destructive" className="flex-1" onClick={handleDisconnect}>
              <LogOut className="h-4 w-4 mr-2" />
              Disconnect Wallet
            </Button>
          </div>
          
          <div className="mt-4 text-xs text-neutral-500 bg-neutral-50 p-3 rounded-md">
            <i className="fa-solid fa-info-circle mr-1 text-primary-500"></i>
            Disconnecting your wallet will sign you out and you will need to reconnect to access your documents and identity again.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

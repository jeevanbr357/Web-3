import { useQuery } from "@tanstack/react-query";
import WalletInfo from "@/components/WalletInfo";
import StatsCard from "@/components/StatsCard";
import DocumentCard from "@/components/DocumentCard";
import ActivityItem from "@/components/ActivityItem";
import DocumentUploadModal from "@/components/modals/DocumentUploadModal";
import { useState } from "react";
import { Loader2 } from "lucide-react";
import { useWallet } from "@/contexts/WalletContext";
import { useDocument } from "@/contexts/DocumentContext";

export default function Dashboard() {
  const { user } = useWallet();
  const { documents } = useDocument();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Fetch stats
  const { data: statsData, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user
  });

  // Fetch activities
  const { data: activitiesData, isLoading: activitiesLoading } = useQuery({
    queryKey: ["/api/activities"],
    enabled: !!user
  });

  // Filter documents based on search query
  const filteredDocuments = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Get the 4 most recent documents
  const recentDocuments = [...filteredDocuments].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  ).slice(0, 4);

  return (
    <div className="p-4 lg:p-8">
      {/* Wallet Information */}
      <WalletInfo 
        onUploadClick={() => setIsUploadModalOpen(true)}
      />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatsCard
          title="My Documents"
          count={statsData?.stats?.documentCount || 0}
          icon="file-lines"
          color="primary"
          change={{ type: "increase", value: "2 new", period: "this week" }}
          loading={statsLoading}
        />
        
        <StatsCard
          title="Document NFTs"
          count={statsData?.stats?.nftCount || 0}
          icon="certificate"
          color="secondary"
          change={{ type: "increase", value: "1 new", period: "this month" }}
          loading={statsLoading}
        />
        
        <StatsCard
          title="Shared With Others"
          count={statsData?.stats?.sharedCount || 0}
          icon="share-nodes"
          color="accent"
          change={{ type: "neutral", value: "4 active shares", period: "" }}
          loading={statsLoading}
        />
      </div>

      {/* Recent Documents */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Recent Documents</h2>
          <div className="flex space-x-2">
            <div className="relative">
              <input
                type="text"
                placeholder="Search documents..."
                className="px-3 py-2 rounded-md border border-neutral-300 text-sm w-full md:w-60 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <i className="fa-solid fa-search absolute right-3 top-2.5 text-neutral-400"></i>
            </div>
            <div className="flex">
              <button 
                className={`px-3 py-2 border border-r-0 rounded-l-md ${viewMode === 'grid' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("grid")}
              >
                <i className="fa-solid fa-table-cells"></i>
              </button>
              <button 
                className={`px-3 py-2 border rounded-r-md ${viewMode === 'list' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("list")}
              >
                <i className="fa-solid fa-list"></i>
              </button>
            </div>
          </div>
        </div>

        {documents.length === 0 ? (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="text-neutral-400 text-4xl mb-3">
              <i className="fa-regular fa-folder-open"></i>
            </div>
            <h3 className="text-lg font-medium text-neutral-800 mb-2">No Documents Yet</h3>
            <p className="text-neutral-600 mb-4">Start by uploading your first secure document</p>
            <button 
              className="px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600 text-sm font-medium"
              onClick={() => setIsUploadModalOpen(true)}
            >
              <i className="fa-solid fa-upload mr-1"></i> Upload Document
            </button>
          </div>
        ) : (
          <div className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" : "space-y-4"}>
            {recentDocuments.map((document) => (
              <DocumentCard 
                key={document.id}
                document={document}
                viewMode={viewMode}
              />
            ))}
          </div>
        )}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm p-4 md:p-6">
        <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
        
        {activitiesLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
          </div>
        ) : activitiesData?.activities?.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-neutral-500">No recent activity</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activitiesData?.activities?.slice(0, 4).map((activity) => (
              <ActivityItem 
                key={activity.id}
                activity={activity}
              />
            ))}
          </div>
        )}
      </div>

      {/* Upload Document Modal */}
      <DocumentUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)} 
      />
    </div>
  );
}

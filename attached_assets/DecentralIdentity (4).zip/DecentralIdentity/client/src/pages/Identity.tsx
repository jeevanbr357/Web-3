import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clipboard, Loader2, Shield, KeyRound, ExternalLink } from "lucide-react";
import { useWallet } from "@/contexts/WalletContext";
import { useToast } from "@/hooks/use-toast";
import exodusLogoPath from "../assets/exodus-logo.svg";

export default function Identity() {
  const { user } = useWallet();
  const { toast } = useToast();
  
  // Fetch detailed DID information
  const { data: didData, isLoading } = useQuery({
    queryKey: ["/api/identity/did"],
    enabled: !!user,
    queryFn: () => {
      // In a real app, this would fetch from the API
      // For this prototype, we'll return mock data based on the user's DID
      return {
        did: user?.did || "",
        controller: user?.walletAddress || "",
        verificationMethod: [
          {
            id: `${user?.did}#keys-1`,
            type: "EcdsaSecp256k1RecoveryMethod2020",
            controller: user?.did,
            publicKeyMultibase: "z6MksSskkfxAFt8mhQmAZM9fUUCgCh..."
          }
        ],
        authentication: [`${user?.did}#keys-1`],
        createdAt: new Date().toISOString(),
        lastUpdated: new Date().toISOString()
      };
    }
  });

  const handleCopyDid = () => {
    if (user?.did) {
      navigator.clipboard.writeText(user.did);
      toast({
        title: "DID Copied",
        description: "Decentralized ID copied to clipboard",
      });
    }
  };

  const handleCopyWalletAddress = () => {
    if (user?.walletAddress) {
      navigator.clipboard.writeText(user.walletAddress);
      toast({
        title: "Wallet Address Copied",
        description: "Wallet address copied to clipboard",
      });
    }
  };

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Decentralized Identity (DID)</h1>
        <p className="text-neutral-600">Manage your Web3 identity credentials</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        </div>
      ) : !user ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-neutral-400 text-4xl mb-3">
            <i className="fa-solid fa-id-card"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No Identity Found</h3>
          <p className="text-neutral-600 mb-4">Please connect your wallet to manage your identity</p>
        </div>
      ) : (
        <>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex justify-between">
                <span>Your Identity</span>
                <div className="flex items-center text-sm font-normal bg-emerald-100 text-emerald-600 px-2 py-1 rounded-full">
                  <i className="fa-solid fa-circle-check mr-1"></i>
                  <span>Verified</span>
                  <img 
                    src={exodusLogoPath} 
                    alt="Exodus Wallet" 
                    className="h-4 w-4 ml-1" 
                  />
                </div>
              </CardTitle>
              <CardDescription>Your decentralized identifier on the blockchain</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-neutral-100 p-3 rounded-md flex items-center justify-between mb-4">
                <code className="font-mono text-sm break-all">{didData?.did}</code>
                <Button variant="ghost" size="sm" onClick={handleCopyDid}>
                  <Clipboard className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium mb-1">Controller</h4>
                  <div className="bg-neutral-100 p-2 rounded-md flex items-center justify-between">
                    <code className="font-mono text-xs break-all">{user.walletAddress}</code>
                    <Button variant="ghost" size="sm" onClick={handleCopyWalletAddress}>
                      <Clipboard className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium mb-1">Created</h4>
                  <div className="bg-neutral-100 p-2 rounded-md text-sm">
                    {new Date(didData?.createdAt || "").toLocaleString()}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="details">
            <TabsList className="mb-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="verification">Verification</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="details">
              <Card>
                <CardHeader>
                  <CardTitle>DID Details</CardTitle>
                  <CardDescription>Technical details of your decentralized identifier</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-1">Verification Method</h4>
                      <div className="bg-neutral-100 p-3 rounded-md">
                        <div className="flex justify-between mb-1">
                          <span className="text-xs text-neutral-500">ID</span>
                          <span className="text-xs text-neutral-500">Type</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <code className="font-mono text-xs">{didData?.verificationMethod[0].id}</code>
                          <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded">
                            {didData?.verificationMethod[0].type}
                          </span>
                        </div>
                        <Separator className="my-2" />
                        <div className="text-xs text-neutral-500 mb-1">Public Key</div>
                        <code className="font-mono text-xs break-all">{didData?.verificationMethod[0].publicKeyMultibase}</code>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-medium mb-1">Authentication</h4>
                      <div className="bg-neutral-100 p-3 rounded-md">
                        <ul className="list-disc list-inside">
                          {didData?.authentication.map((auth, index) => (
                            <li key={index} className="font-mono text-xs">{auth}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm" className="text-xs">
                        <ExternalLink className="h-3 w-3 mr-1" /> View on Explorer
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="verification">
              <Card>
                <CardHeader>
                  <CardTitle>Verification Methods</CardTitle>
                  <CardDescription>Manage how your identity is verified</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 border rounded-md">
                      <div className="flex items-center">
                        <div className="p-2 rounded-full mr-3">
                          <img
                            src={exodusLogoPath}
                            alt="Exodus Wallet"
                            className="h-5 w-5"
                          />
                        </div>
                        <div>
                          <h4 className="font-medium">Exodus Wallet Signature</h4>
                          <p className="text-sm text-neutral-500">Verify using Exodus wallet signature</p>
                        </div>
                      </div>
                      <div className="text-xs bg-emerald-100 text-emerald-600 px-2 py-0.5 rounded">
                        Active
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between p-3 border rounded-md opacity-60">
                      <div className="flex items-center">
                        <div className="bg-neutral-100 p-2 rounded-full text-neutral-600 mr-3">
                          <Shield className="h-4 w-4" />
                        </div>
                        <div>
                          <h4 className="font-medium">Multi-factor Authentication</h4>
                          <p className="text-sm text-neutral-500">Add additional security layers</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" disabled>Coming Soon</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>DID History</CardTitle>
                  <CardDescription>History of changes to your DID document</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3 pb-4 border-b border-neutral-100">
                      <div className="bg-primary-100 text-primary-600 p-2 rounded-full">
                        <i className="fa-solid fa-key"></i>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-800">
                          <span className="font-medium">DID</span> successfully created
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">
                          {new Date(didData?.createdAt || "").toLocaleString()} • 
                          Wallet: {user.walletAddress.substring(0, 8)}...{user.walletAddress.substring(user.walletAddress.length - 4)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="p-2 rounded-full">
                        <img
                          src={exodusLogoPath}
                          alt="Exodus Wallet"
                          className="h-5 w-5"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-800">
                          <span className="font-medium">Exodus Wallet</span> connected to DID
                        </p>
                        <p className="text-xs text-neutral-500 mt-1">
                          {new Date(didData?.createdAt || "").toLocaleString()} •
                          Verified signature
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}

import { useState, useEffect } from "react";
import { useDocument } from "@/contexts/DocumentContext";
import DocumentCard from "@/components/DocumentCard";
import DocumentUploadModal from "@/components/modals/DocumentUploadModal";
import { Button } from "@/components/ui/button";
import { Loader2, Upload } from "lucide-react";

export default function Documents() {
  const { documents, isLoading } = useDocument();
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  // Check for the upload modal flag in session storage
  useEffect(() => {
    const shouldOpenModal = sessionStorage.getItem("openUploadModal");
    if (shouldOpenModal === "true") {
      setIsUploadModalOpen(true);
      // Remove the flag so it doesn't reopen on subsequent renders
      sessionStorage.removeItem("openUploadModal");
    }
  }, []);

  // Filter documents based on search query
  const filteredDocuments = documents.filter(doc => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">My Documents</h1>
          <p className="text-neutral-600">Manage and share your secure documents</p>
        </div>
        <Button 
          className="mt-4 md:mt-0 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-white shadow-md" 
          size="lg"
          onClick={() => setIsUploadModalOpen(true)}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Upload Document
        </Button>
      </div>

      {/* Search and filter */}
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder="Search documents..."
              className="px-3 py-2 rounded-md border border-neutral-300 text-sm w-full focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fa-solid fa-search absolute right-3 top-2.5 text-neutral-400"></i>
          </div>

          <div className="flex gap-2">
            <select className="px-3 py-2 rounded-md border border-neutral-300 text-sm">
              <option value="">All Types</option>
              <option value="Legal document">Legal document</option>
              <option value="Financial document">Financial document</option>
              <option value="Health document">Health document</option>
              <option value="Intellectual property">Intellectual property</option>
              <option value="Personal ID">Personal ID</option>
            </select>

            <div className="flex">
              <button 
                className={`px-3 py-2 border border-r-0 rounded-l-md ${viewMode === 'grid' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("grid")}
              >
                <i className="fa-solid fa-table-cells"></i>
              </button>
              <button 
                className={`px-3 py-2 border rounded-r-md ${viewMode === 'list' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("list")}
              >
                <i className="fa-solid fa-list"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Documents list */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        </div>
      ) : documents.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-neutral-400 text-4xl mb-3">
            <i className="fa-regular fa-folder-open"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No Documents Yet</h3>
          <p className="text-neutral-600 mb-4">Start by uploading your first secure document</p>
          <Button 
            className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-white shadow-md" 
            size="lg"
            onClick={() => setIsUploadModalOpen(true)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            Upload Document
          </Button>
        </div>
      ) : filteredDocuments.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-neutral-400 text-4xl mb-3">
            <i className="fa-solid fa-search"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No Results Found</h3>
          <p className="text-neutral-600">Try adjusting your search criteria</p>
        </div>
      ) : (
        <div className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6" : "space-y-4"}>
          {filteredDocuments.map((document) => (
            <DocumentCard 
              key={document.id}
              document={document}
              viewMode={viewMode}
            />
          ))}
        </div>
      )}

      {/* Upload Document Modal */}
      <DocumentUploadModal 
        isOpen={isUploadModalOpen} 
        onClose={() => setIsUploadModalOpen(false)} 
      />
    </div>
  );
}

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import DocumentCard from "@/components/DocumentCard";
import { Loader2, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWallet } from "@/contexts/WalletContext";

export default function SharedWithMe() {
  const { user } = useWallet();
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  
  // Fetch shared documents
  const { data, isLoading, error } = useQuery({
    queryKey: ["/api/shared-with-me"],
    enabled: !!user
  });
  
  const sharedDocuments = data?.documents || [];
  
  // Filter documents based on search query
  const filteredDocuments = sharedDocuments.filter((doc: any) => 
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-1">Shared With Me</h1>
          <p className="text-neutral-600">Documents others have shared with you</p>
        </div>
      </div>

      {/* Search and filter */}
      <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="relative w-full md:w-96">
            <input
              type="text"
              placeholder="Search shared documents..."
              className="px-3 py-2 rounded-md border border-neutral-300 text-sm w-full focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="fa-solid fa-search absolute right-3 top-2.5 text-neutral-400"></i>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" size="icon">
              <SlidersHorizontal className="h-4 w-4" />
            </Button>
            
            <div className="flex">
              <button 
                className={`px-3 py-2 border border-r-0 rounded-l-md ${viewMode === 'grid' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("grid")}
              >
                <i className="fa-solid fa-table-cells"></i>
              </button>
              <button 
                className={`px-3 py-2 border rounded-r-md ${viewMode === 'list' ? 'bg-neutral-100 text-neutral-800' : 'bg-white text-neutral-600'}`}
                onClick={() => setViewMode("list")}
              >
                <i className="fa-solid fa-list"></i>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Shared documents list */}
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
        </div>
      ) : error ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-red-500 text-4xl mb-3">
            <i className="fa-solid fa-circle-exclamation"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">Error Loading Shared Documents</h3>
          <p className="text-neutral-600 mb-4">Unable to load documents shared with you</p>
        </div>
      ) : filteredDocuments.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-8 text-center">
          <div className="text-neutral-400 text-4xl mb-3">
            <i className="fa-solid fa-share-nodes"></i>
          </div>
          <h3 className="text-lg font-medium text-neutral-800 mb-2">No Shared Documents</h3>
          <p className="text-neutral-600">No one has shared any documents with you yet</p>
        </div>
      ) : (
        <div className={viewMode === 'grid' ? "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6" : "space-y-4"}>
          {filteredDocuments.map((document: any) => (
            <DocumentCard 
              key={document.id}
              document={document}
              viewMode={viewMode}
            />
          ))}
        </div>
      )}
    </div>
  );
}

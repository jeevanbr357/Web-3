import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useWallet } from "@/contexts/WalletContext";
import { useToast } from "@/hooks/use-toast";
import { DOCUMENT_TYPES } from "@shared/schema";

export default function Settings() {
  const { user } = useWallet();
  const { toast } = useToast();
  
  const [username, setUsername] = useState(user?.username || "");
  const [defaultEncryption, setDefaultEncryption] = useState(true);
  const [autoConnectWallet, setAutoConnectWallet] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [defaultDocumentType, setDefaultDocumentType] = useState(DOCUMENT_TYPES[0]);
  
  const handleSaveProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile settings have been saved successfully",
    });
  };
  
  const handleSavePreferences = () => {
    toast({
      title: "Preferences Updated",
      description: "Your document preferences have been saved successfully",
    });
  };
  
  const handleSaveNotifications = () => {
    toast({
      title: "Notification Settings Updated",
      description: "Your notification preferences have been saved successfully",
    });
  };

  return (
    <div className="p-4 lg:p-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-1">Settings</h1>
        <p className="text-neutral-600">Manage your account and application preferences</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="document">Document</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Settings</CardTitle>
              <CardDescription>Manage your personal information and display preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input 
                  id="username" 
                  value={username} 
                  onChange={(e) => setUsername(e.target.value)} 
                  placeholder="Enter username"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="did">Decentralized ID (DID)</Label>
                <Input 
                  id="did" 
                  value={user?.did || ""} 
                  disabled 
                  className="bg-neutral-50 text-neutral-500"
                />
                <p className="text-xs text-neutral-500">Your DID is permanent and cannot be changed</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="wallet">Wallet Address</Label>
                <Input 
                  id="wallet" 
                  value={user?.walletAddress || ""} 
                  disabled 
                  className="bg-neutral-50 text-neutral-500"
                />
                <p className="text-xs text-neutral-500">Connect a different wallet to change this address</p>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="auto-connect" 
                  checked={autoConnectWallet} 
                  onCheckedChange={setAutoConnectWallet}
                />
                <Label htmlFor="auto-connect">Auto-connect wallet on startup</Label>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button onClick={handleSaveProfile}>Save Changes</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="document">
          <Card>
            <CardHeader>
              <CardTitle>Document Preferences</CardTitle>
              <CardDescription>Configure your default document handling preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="default-type">Default Document Type</Label>
                <Select 
                  value={defaultDocumentType} 
                  onValueChange={setDefaultDocumentType}
                >
                  <SelectTrigger id="default-type">
                    <SelectValue placeholder="Select default document type" />
                  </SelectTrigger>
                  <SelectContent>
                    {DOCUMENT_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="encryption" 
                  checked={defaultEncryption} 
                  onCheckedChange={setDefaultEncryption}
                />
                <Label htmlFor="encryption">Encrypt documents by default</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="ipfs-public" />
                <Label htmlFor="ipfs-public">Use public IPFS gateway for document storage</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="auto-nft" />
                <Label htmlFor="auto-nft">Automatically mint NFTs for legal documents</Label>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button onClick={handleSavePreferences}>Save Preferences</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>Configure how and when you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch 
                  id="notifications-enabled" 
                  checked={notificationsEnabled} 
                  onCheckedChange={setNotificationsEnabled}
                />
                <Label htmlFor="notifications-enabled">Enable notifications</Label>
              </div>
              
              <div className="pt-4 space-y-3">
                <h3 className="text-sm font-medium">Notify me about:</h3>
                
                <div className="flex items-center space-x-2 ml-2">
                  <Switch id="notify-shares" defaultChecked />
                  <Label htmlFor="notify-shares">Document shares and access requests</Label>
                </div>
                
                <div className="flex items-center space-x-2 ml-2">
                  <Switch id="notify-nfts" defaultChecked />
                  <Label htmlFor="notify-nfts">NFT minting and transactions</Label>
                </div>
                
                <div className="flex items-center space-x-2 ml-2">
                  <Switch id="notify-wallet" defaultChecked />
                  <Label htmlFor="notify-wallet">Wallet connection events</Label>
                </div>
                
                <div className="flex items-center space-x-2 ml-2">
                  <Switch id="notify-updates" />
                  <Label htmlFor="notify-updates">Platform updates and announcements</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button onClick={handleSaveNotifications}>Save Notification Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>Configure security options for your account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-4">
                <h3 className="text-sm font-medium text-yellow-800 mb-1">Security Notice</h3>
                <p className="text-xs text-yellow-700">
                  Your account security is primarily managed through your Web3 wallet. Make sure to keep your wallet's private keys secure.
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="verification">Verification Method</Label>
                <Select defaultValue="wallet">
                  <SelectTrigger id="verification">
                    <SelectValue placeholder="Select verification method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wallet">Wallet Signature (Default)</SelectItem>
                    <SelectItem value="multi" disabled>Multi-factor Authentication (Coming Soon)</SelectItem>
                    <SelectItem value="biometric" disabled>Biometric Verification (Coming Soon)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="session-timeout" defaultChecked />
                <Label htmlFor="session-timeout">Automatic session timeout after 30 minutes</Label>
              </div>
              
              <div className="space-y-2 pt-4">
                <h3 className="text-sm font-medium">Activity Log</h3>
                <Button variant="outline" className="w-full text-sm">
                  <i className="fa-solid fa-list-ul mr-2"></i>
                  View Account Activity
                </Button>
              </div>
            </CardContent>
            <CardFooter className="border-t pt-6 flex justify-between">
              <Button variant="outline">Cancel</Button>
              <Button>Save Security Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

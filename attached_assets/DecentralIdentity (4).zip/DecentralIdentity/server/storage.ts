import { 
  users, documents, documentShares, activities,
  type User, type InsertUser,
  type Document, type InsertDocument,
  type DocumentShare, type InsertDocumentShare,
  type Activity, type InsertActivity
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByDid(did: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Document methods
  getDocument(id: number): Promise<Document | undefined>;
  getDocumentsByUserId(userId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<Document>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
  
  // Document sharing methods
  getDocumentShare(id: number): Promise<DocumentShare | undefined>;
  getDocumentSharesByDocumentId(documentId: number): Promise<DocumentShare[]>;
  getDocumentSharesByRecipientDid(did: string): Promise<DocumentShare[]>;
  createDocumentShare(share: InsertDocumentShare): Promise<DocumentShare>;
  updateDocumentShare(id: number, share: Partial<DocumentShare>): Promise<DocumentShare | undefined>;
  
  // Activity methods
  getActivitiesByUserId(userId: number): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private documents: Map<number, Document>;
  private documentShares: Map<number, DocumentShare>;
  private activities: Map<number, Activity>;
  private userId: number;
  private documentId: number;
  private documentShareId: number;
  private activityId: number;

  constructor() {
    this.users = new Map();
    this.documents = new Map();
    this.documentShares = new Map();
    this.activities = new Map();
    this.userId = 1;
    this.documentId = 1;
    this.documentShareId = 1;
    this.activityId = 1;
    
    // Create a default public user for anonymous uploads
    const publicUser: User = {
      id: 1,
      username: "anonymous",
      did: "did:web3:anonymous",
      walletAddress: null,
      publicKey: null,
      createdAt: new Date()
    };
    this.users.set(publicUser.id, publicUser);
    
    console.log("Created default public user for anonymous document uploads");
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByDid(did: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.did === did,
    );
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    
    // Ensure all required fields are properly set
    const user: User = { 
      id, 
      username: insertUser.username,
      did: insertUser.did,
      walletAddress: insertUser.walletAddress ?? null,
      publicKey: insertUser.publicKey ?? null,
      createdAt: insertUser.createdAt ?? now
    };
    
    this.users.set(id, user);
    return user;
  }

  // Document methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentsByUserId(userId: number): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (document) => document.userId === userId,
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.documentId++;
    const now = new Date();
    
    // Ensure all required fields are present with defaults if not provided
    const document: Document = { 
      ...insertDocument, 
      id, 
      description: insertDocument.description || null,
      encryptionKey: insertDocument.encryptionKey || null,
      isEncrypted: insertDocument.isEncrypted || false,
      isNft: insertDocument.isNft || false,
      nftTokenId: insertDocument.nftTokenId || null,
      nftContractAddress: insertDocument.nftContractAddress || null,
      createdAt: now, 
      updatedAt: now 
    };
    
    this.documents.set(id, document);
    return document;
  }

  async updateDocument(id: number, update: Partial<Document>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument: Document = {
      ...document,
      ...update,
      updatedAt: new Date(),
    };
    
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Document sharing methods
  async getDocumentShare(id: number): Promise<DocumentShare | undefined> {
    return this.documentShares.get(id);
  }

  async getDocumentSharesByDocumentId(documentId: number): Promise<DocumentShare[]> {
    return Array.from(this.documentShares.values()).filter(
      (share) => share.documentId === documentId,
    );
  }

  async getDocumentSharesByRecipientDid(did: string): Promise<DocumentShare[]> {
    // Only include active shares (those that haven't expired)
    const now = new Date();
    return Array.from(this.documentShares.values()).filter(
      (share) => share.recipientDid === did && 
                 (!share.expiresAt || share.expiresAt > now)
    );
  }

  async createDocumentShare(insertShare: InsertDocumentShare): Promise<DocumentShare> {
    const id = this.documentShareId++;
    const now = new Date();
    
    // Ensure all required fields are present with defaults if not provided
    const share: DocumentShare = { 
      ...insertShare, 
      id, 
      message: insertShare.message || null,
      transactionHash: insertShare.transactionHash || null,
      expiresAt: insertShare.expiresAt || null,
      createdAt: now 
    };
    
    this.documentShares.set(id, share);
    return share;
  }

  async updateDocumentShare(id: number, update: Partial<DocumentShare>): Promise<DocumentShare | undefined> {
    const share = this.documentShares.get(id);
    if (!share) return undefined;
    
    const updatedShare: DocumentShare = {
      ...share,
      ...update,
    };
    
    this.documentShares.set(id, updatedShare);
    return updatedShare;
  }

  // Activity methods
  async getActivitiesByUserId(userId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter((activity) => activity.userId === userId)
      .sort((a, b) => {
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.activityId++;
    const now = new Date();
    
    // Ensure all required fields are present with defaults if not provided
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      documentId: insertActivity.documentId || null,
      metadata: insertActivity.metadata || {},
      createdAt: now 
    };
    
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();

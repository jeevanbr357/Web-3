import express from 'express';
import { createServer } from 'http';
import cors from 'cors';
import multer from 'multer';
import { storage } from './storage';
import * as ipfsMock from './lib/ipfs-mock';

// Create Express app and HTTP server
const app = express();
const server = createServer(app);
const port = 5000;

// Configure middleware
app.use(express.json());
app.use(cors({
  origin: 'http://localhost:5173', // Vite dev server default
  credentials: true
}));

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Simple session handling for local development
const sessions: Record<string, any> = {};

// In-memory storage for document content by CID
const documentStore = new Map<string, Buffer>();

// Endpoints for local development

// Get user profile or public info
app.get('/api/user', (req, res) => {
  // Simulate a logged-in user for local development
  const mockUser = {
    id: 2,
    username: 'testuser',
    did: 'did:web:example.com:testuser',
    walletAddress: '0x1234567890123456789012345678901234567890'
  };
  
  res.json(mockUser);
});

// Get anonymous user for document uploads without wallet
app.get('/api/anonymous-user', (req, res) => {
  const anonymousUser = {
    id: 1,
    username: 'anonymous',
    did: 'did:web:anonymous',
    walletAddress: null
  };
  
  res.json(anonymousUser);
});

// Connect wallet - simulated
app.post('/api/wallet/connect', (req, res) => {
  const { address, signature } = req.body;
  
  // In a real implementation, verify the signature
  // For development, just simulate success
  const sessionId = Math.random().toString(36).substring(2);
  sessions[sessionId] = {
    userId: 2,
    walletAddress: address
  };
  
  res.cookie('sessionId', sessionId, { httpOnly: true });
  res.json({ success: true });
});

// Mock document APIs

// Get all documents
app.get('/api/documents', async (req, res) => {
  const documents = await storage.getDocumentsByUserId(2); // Mock user ID
  res.json(documents);
});

// Upload document
app.post('/api/documents', upload.single('file'), async (req, res) => {
  const { title, type, description, encrypt, mintAsNft } = req.body;
  const file = req.file;
  
  if (!file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
  try {
    // Mock IPFS upload
    const ipfsCid = await ipfsMock.storeFile(file.buffer);
    
    // Store the actual file content in memory for retrieval
    documentStore.set(ipfsCid, file.buffer);
    
    let encryptionKey = null;
    if (encrypt === 'true') {
      encryptionKey = 'mock-encryption-key-' + Math.random().toString(36).substring(2);
    }
    
    // Create document record
    const document = await storage.createDocument({
      userId: 2, // Mock user ID
      title,
      type,
      description: description || null,
      ipfsCid,
      encryptionKey,
      isEncrypted: encrypt === 'true',
      isNft: mintAsNft === 'true',
      nftTokenId: mintAsNft === 'true' ? '1' : null,
      nftContractAddress: mintAsNft === 'true' ? '0xMockContract' : null,
    });
    
    // Create activity record
    await storage.createActivity({
      userId: 2,
      type: 'DOCUMENT_UPLOAD',
      documentId: document.id,
      metadata: { title: document.title }
    });
    
    res.status(201).json(document);
  } catch (error) {
    console.error('Error uploading document:', error);
    res.status(500).json({ error: 'Failed to upload document' });
  }
});

// Share document
app.post('/api/documents/:documentId/share', async (req, res) => {
  const { documentId } = req.params;
  const { recipientDid, accessLevel, accessDuration, message } = req.body;
  
  try {
    const document = await storage.getDocument(parseInt(documentId));
    if (!document) {
      return res.status(404).json({ error: 'Document not found' });
    }
    
    // Create share record
    const share = await storage.createDocumentShare({
      documentId: parseInt(documentId),
      senderUserId: 2, // Mock user ID
      recipientDid,
      accessLevel,
      expiresAt: accessDuration === 'never' ? null : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days by default
      message: message || null,
      transactionHash: 'mock-tx-' + Math.random().toString(36).substring(2)
    });
    
    // Create activity
    await storage.createActivity({
      userId: 2,
      type: 'DOCUMENT_SHARE',
      documentId: parseInt(documentId),
      metadata: { recipientDid, documentTitle: document.title }
    });
    
    res.status(201).json(share);
  } catch (error) {
    console.error('Error sharing document:', error);
    res.status(500).json({ error: 'Failed to share document' });
  }
});

// Endpoint to serve document content by CID
app.get('/api/ipfs/:cid', async (req, res) => {
  const { cid } = req.params;
  
  try {
    console.log(`Attempting to retrieve document with CID: ${cid}`);
    
    // Check if we have this document in our store
    if (documentStore.has(cid)) {
      console.log(`Document found in local store: ${cid}`);
      // Get the content from our store
      const content = documentStore.get(cid);
      
      if (!content) {
        console.error(`Document content empty for CID: ${cid}`);
        return res.status(404).json({ error: 'Document content not found' });
      }
      
      // Try to determine content type (basic implementation)
      const fileType = detectFileType(content);
      console.log(`Serving document with detected content type: ${fileType}`);
      res.set('Content-Type', fileType);
      
      return res.send(content);
    } else {
      console.log(`Document not found in local store, checking mock IPFS: ${cid}`);
    }
    
    // If not in store, try to get it from mock IPFS
    try {
      const content = await ipfsMock.retrieveFile(cid);
      if (!content || content.length === 0) {
        console.error(`Empty content returned from IPFS for CID: ${cid}`);
        return res.status(404).json({ error: 'Empty document content in IPFS' });
      }
      
      // Try to determine content type
      const fileType = detectFileType(content);
      console.log(`Serving document from IPFS with content type: ${fileType}`);
      res.set('Content-Type', fileType);
      
      return res.send(content);
    } catch (error) {
      console.error(`Error retrieving document from IPFS for CID: ${cid}`, error);
      return res.status(404).json({ error: 'Document not found in IPFS' });
    }
  } catch (error) {
    console.error(`Error serving document with CID: ${cid}`, error);
    res.status(500).json({ error: 'Failed to serve document' });
  }
});

// Basic file type detection
function detectFileType(buffer: Buffer): string {
  // Check for PDF signature
  if (buffer.length >= 4 && buffer[0] === 0x25 && buffer[1] === 0x50 && 
      buffer[2] === 0x44 && buffer[3] === 0x46) {
    return 'application/pdf';
  }
  
  // Check for PNG signature
  if (buffer.length >= 8 && buffer[0] === 0x89 && buffer[1] === 0x50 && 
      buffer[2] === 0x4e && buffer[3] === 0x47 && buffer[4] === 0x0d && 
      buffer[5] === 0x0a && buffer[6] === 0x1a && buffer[7] === 0x0a) {
    return 'image/png';
  }
  
  // Check for JPEG signature
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    return 'image/jpeg';
  }
  
  // Default to text
  return 'text/plain';
}

// Start server
server.listen(port, () => {
  console.log(`[Local Dev Server] Running at http://localhost:${port}`);
  console.log('[Local Dev Server] Use this for local development with the frontend running on http://localhost:5173');
});

export default server;
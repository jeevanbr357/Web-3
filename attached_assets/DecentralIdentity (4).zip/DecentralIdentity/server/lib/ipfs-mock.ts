/**
 * Mock implementation of IPFS client functions to avoid dependency issues
 */

// Generate a random string for mock CIDs
function generateRandomId(length = 10) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Store a file on IPFS (mock implementation)
 */
export async function storeFile(fileBuffer: Buffer): Promise<string> {
  console.log('[MOCK IPFS] Storing file of size', fileBuffer.length);
  // Generate a fake CID
  const mockCid = `Qm${generateRandomId(44)}`;
  return mockCid;
}

/**
 * Retrieve a file from IPFS (mock implementation)
 */
export async function retrieveFile(cid: string): Promise<Buffer> {
  console.log('[MOCK IPFS] Retrieving file with CID:', cid);
  // Return an empty buffer
  return Buffer.from('Mock file content for ' + cid);
}

/**
 * Get the IPFS gateway URL for a CID
 */
export function getIpfsGatewayUrl(cid: string): string {
  return `https://ipfs.io/ipfs/${cid}`;
}

/**
 * Pin a file on IPFS to ensure it remains available (mock)
 */
export async function pinFile(cid: string): Promise<boolean> {
  console.log('[MOCK IPFS] Pinning file with CID:', cid);
  return true;
}

/**
 * Unpin a file from IPFS (mock)
 */
export async function unpinFile(cid: string): Promise<boolean> {
  console.log('[MOCK IPFS] Unpinning file with CID:', cid);
  return true;
}
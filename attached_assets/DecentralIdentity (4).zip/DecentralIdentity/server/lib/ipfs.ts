import { create, IPFSHTTPClient } from 'ipfs-http-client';

// Initialize IPFS client
let ipfsClient: IPFSHTTPClient | null = null;

const IPFS_API_URL = process.env.IPFS_API_URL || 'https://ipfs.infura.io:5001';
const IPFS_API_PROJECT_ID = process.env.IPFS_API_PROJECT_ID;
const IPFS_API_SECRET = process.env.IPFS_API_SECRET;

/**
 * Initialize the IPFS client
 */
function initializeIPFSClient() {
  if (ipfsClient) return;
  
  try {
    // If we have authentication credentials, use them
    if (IPFS_API_PROJECT_ID && IPFS_API_SECRET) {
      const auth = 'Basic ' + Buffer.from(IPFS_API_PROJECT_ID + ':' + IPFS_API_SECRET).toString('base64');
      
      ipfsClient = create({
        url: IPFS_API_URL,
        headers: {
          authorization: auth
        }
      });
    } else {
      // Otherwise try to connect without auth
      ipfsClient = create({ url: IPFS_API_URL });
    }
  } catch (error) {
    console.error('Error initializing IPFS client:', error);
    throw new Error('Failed to initialize IPFS client');
  }
}

/**
 * Store a file on IPFS
 * 
 * @param fileBuffer - The file buffer to store
 * @returns The IPFS CID of the stored file
 */
export async function storeFile(fileBuffer: Buffer): Promise<string> {
  try {
    // For development, return a mock CID if IPFS is not configured
    if (process.env.NODE_ENV !== 'production' && (!IPFS_API_PROJECT_ID || !IPFS_API_SECRET)) {
      const mockCid = `Qm${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
      console.log(`[MOCK] Stored file with CID: ${mockCid}`);
      return mockCid;
    }
    
    // Initialize IPFS client if needed
    if (!ipfsClient) {
      initializeIPFSClient();
    }
    
    if (!ipfsClient) {
      throw new Error('IPFS client not initialized');
    }
    
    // Add the file to IPFS
    const result = await ipfsClient.add(fileBuffer);
    
    console.log(`Stored file with CID: ${result.cid.toString()}`);
    return result.cid.toString();
  } catch (error) {
    console.error('Error storing file on IPFS:', error);
    throw new Error('Failed to store file on IPFS');
  }
}

/**
 * Retrieve a file from IPFS
 * 
 * @param cid - The IPFS CID of the file
 * @returns The file buffer
 */
export async function retrieveFile(cid: string): Promise<Buffer> {
  try {
    // For development, return a mock buffer if IPFS is not configured
    if (process.env.NODE_ENV !== 'production' && (!IPFS_API_PROJECT_ID || !IPFS_API_SECRET)) {
      console.log(`[MOCK] Retrieved file with CID: ${cid}`);
      return Buffer.from('Mock file content');
    }
    
    // Initialize IPFS client if needed
    if (!ipfsClient) {
      initializeIPFSClient();
    }
    
    if (!ipfsClient) {
      throw new Error('IPFS client not initialized');
    }
    
    // Fetch the file from IPFS
    const chunks: Uint8Array[] = [];
    for await (const chunk of ipfsClient.cat(cid)) {
      chunks.push(chunk);
    }
    
    // Combine chunks into a single buffer
    const fileBuffer = Buffer.concat(chunks);
    
    console.log(`Retrieved file with CID: ${cid}, size: ${fileBuffer.length} bytes`);
    return fileBuffer;
  } catch (error) {
    console.error('Error retrieving file from IPFS:', error);
    throw new Error('Failed to retrieve file from IPFS');
  }
}

/**
 * Get the IPFS gateway URL for a CID
 * 
 * @param cid - The IPFS CID
 * @returns The IPFS gateway URL
 */
export function getIpfsGatewayUrl(cid: string): string {
  const gateway = process.env.IPFS_GATEWAY_URL || 'https://ipfs.io/ipfs/';
  return `${gateway}${cid}`;
}

/**
 * Pin a file on IPFS to ensure it remains available
 * 
 * @param cid - The IPFS CID of the file to pin
 * @returns Boolean indicating success
 */
export async function pinFile(cid: string): Promise<boolean> {
  try {
    // For development, return success if IPFS is not configured
    if (process.env.NODE_ENV !== 'production' && (!IPFS_API_PROJECT_ID || !IPFS_API_SECRET)) {
      console.log(`[MOCK] Pinned file with CID: ${cid}`);
      return true;
    }
    
    // Initialize IPFS client if needed
    if (!ipfsClient) {
      initializeIPFSClient();
    }
    
    if (!ipfsClient) {
      throw new Error('IPFS client not initialized');
    }
    
    // Pin the file
    await ipfsClient.pin.add(cid);
    
    console.log(`Pinned file with CID: ${cid}`);
    return true;
  } catch (error) {
    console.error('Error pinning file on IPFS:', error);
    return false;
  }
}

/**
 * Unpin a file from IPFS
 * 
 * @param cid - The IPFS CID of the file to unpin
 * @returns Boolean indicating success
 */
export async function unpinFile(cid: string): Promise<boolean> {
  try {
    // For development, return success if IPFS is not configured
    if (process.env.NODE_ENV !== 'production' && (!IPFS_API_PROJECT_ID || !IPFS_API_SECRET)) {
      console.log(`[MOCK] Unpinned file with CID: ${cid}`);
      return true;
    }
    
    // Initialize IPFS client if needed
    if (!ipfsClient) {
      initializeIPFSClient();
    }
    
    if (!ipfsClient) {
      throw new Error('IPFS client not initialized');
    }
    
    // Unpin the file
    await ipfsClient.pin.rm(cid);
    
    console.log(`Unpinned file with CID: ${cid}`);
    return true;
  } catch (error) {
    console.error('Error unpinning file from IPFS:', error);
    return false;
  }
}

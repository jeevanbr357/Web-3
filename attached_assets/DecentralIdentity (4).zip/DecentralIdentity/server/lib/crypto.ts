import crypto from 'crypto';

/**
 * Generate a random encryption key
 */
export function generateEncryptionKey(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Generate key pair for asymmetric encryption
 */
export async function generateKeyPair(): Promise<{ publicKey: string, privateKey: string }> {
  return new Promise((resolve, reject) => {
    crypto.generateKeyPair('rsa', {
      modulusLength: 2048,
      publicKeyEncoding: {
        type: 'spki',
        format: 'pem'
      },
      privateKeyEncoding: {
        type: 'pkcs8',
        format: 'pem'
      }
    }, (err, publicKey, privateKey) => {
      if (err) {
        reject(err);
      } else {
        resolve({ publicKey, privateKey });
      }
    });
  });
}

/**
 * Encrypt file buffer using AES-256-GCM
 * 
 * @param fileBuffer - The file buffer to encrypt
 * @returns The encrypted buffer and the key used for encryption
 */
export async function encryptFile(fileBuffer: Buffer): Promise<{ encryptedBuffer: Buffer, key: string }> {
  // Generate a random encryption key
  const key = crypto.randomBytes(32);
  const iv = crypto.randomBytes(16);
  
  // Create cipher
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  
  // Encrypt the file
  const encryptedBuffer = Buffer.concat([
    iv,
    cipher.update(fileBuffer),
    cipher.final(),
    cipher.getAuthTag()
  ]);
  
  return {
    encryptedBuffer,
    key: key.toString('hex')
  };
}

/**
 * Decrypt file buffer
 * 
 * @param encryptedBuffer - The encrypted file buffer
 * @param keyHex - The encryption key in hexadecimal string format
 * @returns The decrypted buffer
 */
export function decryptFile(encryptedBuffer: Buffer, keyHex: string): Buffer {
  // Extract IV and auth tag from the encrypted buffer
  const iv = encryptedBuffer.subarray(0, 16);
  const authTag = encryptedBuffer.subarray(encryptedBuffer.length - 16);
  const encryptedContent = encryptedBuffer.subarray(16, encryptedBuffer.length - 16);
  
  // Convert key from hex string to buffer
  const key = Buffer.from(keyHex, 'hex');
  
  // Create decipher
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  
  // Decrypt the file
  return Buffer.concat([
    decipher.update(encryptedContent),
    decipher.final()
  ]);
}

/**
 * Hash sensitive data like passwords
 */
export function hashData(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Generate a secure random string
 */
export function generateRandomString(length: number = 32): string {
  return crypto.randomBytes(Math.ceil(length / 2))
    .toString('hex')
    .slice(0, length);
}

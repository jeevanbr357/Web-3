import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertDocumentSchema, 
  insertDocumentShareSchema, 
  insertActivitySchema,
  ACTIVITY_TYPES
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import multer from "multer";
import { storeFile, retrieveFile } from "./lib/ipfs";
import { encryptFile, generateKeyPair } from "./lib/crypto";
import { createDid, verifyDid } from "./lib/did";
import { mintNFT, verifyNFTOwnership } from "./lib/web3";
import session from "express-session";
import MemoryStore from "memorystore";

const MemoryStoreSession = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "secure-id-web3-session-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 86400000 },
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      })
    })
  );
  
  // Setup file upload middleware
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 25 * 1024 * 1024 } // 25MB
  });
  
  // Middleware to check if user is authenticated
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Authentication and User routes
  app.post("/api/auth/connect-wallet", async (req, res) => {
    try {
      const { walletAddress, signature } = req.body;
      
      if (!walletAddress || !signature) {
        return res.status(400).json({ message: "Wallet address and signature required" });
      }
      
      // Verify the signature
      // In a real application, we'd verify the signature matches the wallet address
      
      // Check if user exists
      let user = await storage.getUserByWalletAddress(walletAddress);
      
      if (!user) {
        // Generate a new DID for the user
        const { did, publicKey } = await createDid(walletAddress);
        
        // Create new user
        user = await storage.createUser({
          username: `user-${walletAddress.substring(0, 8)}`,
          password: "", // We don't use password with wallet auth
          did,
          walletAddress,
          publicKey,
        });
        
        // Record activity
        await storage.createActivity({
          userId: user.id,
          activityType: ACTIVITY_TYPES.DID_CREATE,
          details: { did, walletAddress }
        });
      }
      
      // Log wallet connection activity
      await storage.createActivity({
        userId: user.id,
        activityType: ACTIVITY_TYPES.WALLET_CONNECT,
        details: { walletAddress }
      });
      
      // Set session
      req.session.userId = user.id;
      req.session.did = user.did;
      req.session.walletAddress = user.walletAddress;
      
      res.status(200).json({
        message: "Wallet connected successfully",
        user: {
          id: user.id,
          username: user.username,
          did: user.did,
          walletAddress: user.walletAddress
        }
      });
    } catch (error) {
      console.error("Error connecting wallet:", error);
      res.status(500).json({ message: "Failed to connect wallet" });
    }
  });
  
  app.post("/api/auth/disconnect", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to disconnect" });
      }
      res.status(200).json({ message: "Disconnected successfully" });
    });
  });
  
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.status(200).json({
        user: {
          id: user.id,
          username: user.username,
          did: user.did,
          walletAddress: user.walletAddress
        }
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user information" });
    }
  });
  
  // Document management routes - No auth required
  app.post("/api/documents", upload.single("file"), async (req, res) => {
    try {
      // If user is logged in, use their ID, otherwise assign to a default guest user
      const userId = req.session.userId || 1; // Using ID 1 as default for guest uploads
      const { title, type, description, encrypt, mintAsNft } = req.body;
      
      // Validate request
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      try {
        const data = insertDocumentSchema.parse({
          userId, 
          title,
          type,
          description: description || "Uploaded document",
          ipfsCid: "", // Will be set after IPFS upload
          isEncrypted: encrypt === "true" || encrypt === true,
          isNft: mintAsNft === "true" || mintAsNft === true
        });
        
        // Handle file
        let ipfsCid;
        let encryptionKey = null;
        
        if (data.isEncrypted) {
          // Encrypt file before uploading
          const { encryptedBuffer, key } = await encryptFile(req.file.buffer);
          ipfsCid = await storeFile(encryptedBuffer);
          encryptionKey = key;
        } else {
          // Store original file
          ipfsCid = await storeFile(req.file.buffer);
        }
        
        // Create document record
        const document = await storage.createDocument({
          ...data,
          ipfsCid,
          encryptionKey,
        });
        
        // Record activity
        await storage.createActivity({
          userId,
          documentId: document.id,
          activityType: ACTIVITY_TYPES.DOCUMENT_UPLOAD,
          details: { title, type, isEncrypted: data.isEncrypted }
        });
        
        // If NFT option selected, mint NFT
        if (data.isNft) {
          // If user is not authenticated, we can't mint an NFT
          if (!req.session.walletAddress) {
            return res.status(400).json({
              message: "Authentication required for NFT creation. Please connect your wallet first."
            });
          }
          
          try {
            const walletAddress = req.session.walletAddress;
            const { tokenId, contractAddress } = await mintNFT(title, ipfsCid, walletAddress);
            
            // Update document with NFT info
            await storage.updateDocument(document.id, {
              nftTokenId: tokenId,
              nftContractAddress: contractAddress
            });
            
            // Record NFT minting activity
            await storage.createActivity({
              userId,
              documentId: document.id,
              activityType: ACTIVITY_TYPES.DOCUMENT_NFT_MINT,
              details: { tokenId, contractAddress }
            });
          } catch (nftError) {
            console.error("Error minting NFT:", nftError);
            // Still return success but note NFT minting failed
            return res.status(201).json({
              document: {
                id: document.id,
                title: document.title,
                type: document.type,
                isEncrypted: document.isEncrypted,
                isNft: document.isNft
              },
              message: "Document uploaded successfully but NFT minting failed"
            });
          }
        }
        
        res.status(201).json({
          document: {
            id: document.id,
            title: document.title,
            type: document.type,
            isEncrypted: document.isEncrypted,
            isNft: document.isNft,
            nftTokenId: document.nftTokenId,
            nftContractAddress: document.nftContractAddress
          },
          message: "Document uploaded successfully"
        });
      } catch (validationError) {
        if (validationError instanceof ZodError) {
          const readableError = fromZodError(validationError);
          return res.status(400).json({ message: readableError.message });
        }
        throw validationError;
      }
    } catch (error) {
      console.error("Error uploading document:", error);
      res.status(500).json({ message: "Failed to upload document" });
    }
  });
  
  app.get("/api/documents", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const documents = await storage.getDocumentsByUserId(userId);
      
      res.status(200).json({
        documents: documents.map(doc => ({
          id: doc.id,
          title: doc.title,
          type: doc.type,
          description: doc.description,
          ipfsCid: doc.ipfsCid,
          isEncrypted: doc.isEncrypted,
          isNft: doc.isNft,
          nftTokenId: doc.nftTokenId,
          nftContractAddress: doc.nftContractAddress,
          createdAt: doc.createdAt,
          updatedAt: doc.updatedAt
        }))
      });
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });
  
  app.get("/api/documents/:id", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const documentId = parseInt(req.params.id);
      
      if (isNaN(documentId)) {
        return res.status(400).json({ message: "Invalid document ID" });
      }
      
      const document = await storage.getDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      // Check if user owns the document or has access through a share
      if (document.userId !== userId) {
        const userDid = req.session.did!;
        const shares = await storage.getDocumentSharesByRecipientDid(userDid);
        const hasAccess = shares.some(share => 
          share.documentId === documentId && share.isActive
        );
        
        if (!hasAccess) {
          return res.status(403).json({ message: "Access denied" });
        }
      }
      
      res.status(200).json({ document });
    } catch (error) {
      console.error("Error fetching document:", error);
      res.status(500).json({ message: "Failed to fetch document" });
    }
  });
  
  // Document sharing routes
  app.post("/api/documents/:id/share", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const documentId = parseInt(req.params.id);
      
      if (isNaN(documentId)) {
        return res.status(400).json({ message: "Invalid document ID" });
      }
      
      const document = await storage.getDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      // Verify user owns the document
      if (document.userId !== userId) {
        return res.status(403).json({ message: "Access denied - you don't own this document" });
      }
      
      try {
        const { recipientDid, accessLevel, accessDuration, message } = req.body;
        
        // Validate DID
        const isValidDid = await verifyDid(recipientDid);
        if (!isValidDid) {
          return res.status(400).json({ message: "Invalid recipient DID" });
        }
        
        // TODO: In a real implementation, deploy an access contract
        // For now, we'll just create the share record
        const shareData = insertDocumentShareSchema.parse({
          documentId,
          ownerId: userId,
          recipientDid,
          accessLevel,
          accessDuration,
          message,
          isActive: true,
          expiresAt: accessDuration === "Unlimited" ? null : 
            new Date(Date.now() + getExpirationTime(accessDuration))
        });
        
        const share = await storage.createDocumentShare(shareData);
        
        // Record activity
        await storage.createActivity({
          userId,
          documentId,
          activityType: ACTIVITY_TYPES.DOCUMENT_SHARE,
          details: { recipientDid, accessLevel, accessDuration }
        });
        
        res.status(201).json({
          share: {
            id: share.id,
            documentId: share.documentId,
            recipientDid: share.recipientDid,
            accessLevel: share.accessLevel,
            accessDuration: share.accessDuration,
            expiresAt: share.expiresAt
          },
          message: "Document shared successfully"
        });
      } catch (validationError) {
        if (validationError instanceof ZodError) {
          const readableError = fromZodError(validationError);
          return res.status(400).json({ message: readableError.message });
        }
        throw validationError;
      }
    } catch (error) {
      console.error("Error sharing document:", error);
      res.status(500).json({ message: "Failed to share document" });
    }
  });
  
  app.get("/api/shared-with-me", requireAuth, async (req, res) => {
    try {
      const userDid = req.session.did!;
      const shares = await storage.getDocumentSharesByRecipientDid(userDid);
      
      // Fetch document details for each share
      const sharedDocuments = await Promise.all(
        shares.map(async (share) => {
          const document = await storage.getDocument(share.documentId);
          if (!document) return null;
          
          return {
            id: document.id,
            title: document.title,
            type: document.type,
            ipfsCid: document.ipfsCid,
            isEncrypted: document.isEncrypted,
            isNft: document.isNft,
            shareId: share.id,
            sharedBy: share.ownerId,
            accessLevel: share.accessLevel,
            expiresAt: share.expiresAt,
            createdAt: share.createdAt,
            updatedAt: document.updatedAt
          };
        })
      );
      
      // Filter out null values (documents that weren't found)
      const validDocuments = sharedDocuments.filter(doc => doc !== null);
      
      res.status(200).json({ documents: validDocuments });
    } catch (error) {
      console.error("Error fetching shared documents:", error);
      res.status(500).json({ message: "Failed to fetch shared documents" });
    }
  });
  
  // User activity routes
  app.get("/api/activities", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const activities = await storage.getActivitiesByUserId(userId);
      
      res.status(200).json({ activities });
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });
  
  // IPFS document retrieval endpoint
  app.get('/api/ipfs/:cid', async (req, res) => {
    const { cid } = req.params;
    
    try {
      console.log(`Attempting to retrieve content from IPFS with CID: ${cid}`);
      const content = await retrieveFile(cid);
      
      if (!content || content.length === 0) {
        console.error(`Empty content returned from IPFS for CID: ${cid}`);
        return res.status(404).json({ error: 'Empty document content in IPFS' });
      }
      
      // Try to determine content type from the buffer
      const fileType = detectFileType(content);
      console.log(`Serving document from IPFS with detected type: ${fileType}`);
      res.set('Content-Type', fileType);
      
      res.send(content);
    } catch (error) {
      console.error(`Error retrieving from IPFS for CID: ${cid}:`, error);
      res.status(404).json({ error: 'File not found in IPFS' });
    }
  });
  
  // Helper function to detect file type from buffer
  function detectFileType(buffer: Buffer): string {
    // Check for PDF signature
    if (buffer.length >= 4 && buffer[0] === 0x25 && buffer[1] === 0x50 && 
        buffer[2] === 0x44 && buffer[3] === 0x46) {
      return 'application/pdf';
    }
    
    // Check for PNG signature
    if (buffer.length >= 8 && buffer[0] === 0x89 && buffer[1] === 0x50 && 
        buffer[2] === 0x4e && buffer[3] === 0x47 && buffer[4] === 0x0d && 
        buffer[5] === 0x0a && buffer[6] === 0x1a && buffer[7] === 0x0a) {
      return 'image/png';
    }
    
    // Check for JPEG signature
    if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
      return 'image/jpeg';
    }
    
    // Default to text
    return 'text/plain';
  }
  
  // NFT routes
  app.get("/api/nfts", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const documents = await storage.getDocumentsByUserId(userId);
      
      // Filter documents that have been minted as NFTs
      const nftDocuments = documents.filter(doc => doc.isNft && doc.nftTokenId);
      
      res.status(200).json({
        nfts: nftDocuments.map(doc => ({
          id: doc.id,
          title: doc.title,
          type: doc.type,
          ipfsCid: doc.ipfsCid,
          tokenId: doc.nftTokenId,
          contractAddress: doc.nftContractAddress,
          createdAt: doc.createdAt,
          updatedAt: doc.updatedAt
        }))
      });
    } catch (error) {
      console.error("Error fetching NFTs:", error);
      res.status(500).json({ message: "Failed to fetch NFTs" });
    }
  });
  
  // Stats routes
  app.get("/api/stats", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const documents = await storage.getDocumentsByUserId(userId);
      
      // Count different document types
      const documentCount = documents.length;
      const nftCount = documents.filter(doc => doc.isNft).length;
      
      // Count shared documents
      const sharedCount = (await Promise.all(
        documents.map(async doc => {
          const shares = await storage.getDocumentSharesByDocumentId(doc.id);
          return shares.filter(share => share.isActive).length;
        })
      )).reduce((sum, count) => sum + count, 0);
      
      res.status(200).json({
        stats: {
          documentCount,
          nftCount,
          sharedCount
        }
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

// Helper function to calculate expiration time in milliseconds
function getExpirationTime(duration: string): number {
  const day = 24 * 60 * 60 * 1000;
  switch (duration) {
    case "7 days": return 7 * day;
    case "30 days": return 30 * day;
    case "90 days": return 90 * day;
    case "1 year": return 365 * day;
    default: return 0; // Unlimited
  }
}

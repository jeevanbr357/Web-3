import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  did: text("did").notNull().unique(),
  walletAddress: text("wallet_address").unique(), // Can be null for anonymous users
  publicKey: text("public_key"), // Can be null for anonymous users
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  ipfsCid: text("ipfs_cid").notNull(),
  encryptionKey: text("encryption_key"),
  isEncrypted: boolean("is_encrypted").notNull().default(false),
  isNft: boolean("is_nft").notNull().default(false),
  nftTokenId: text("nft_token_id"),
  nftContractAddress: text("nft_contract_address"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const documentShares = pgTable("document_shares", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull().references(() => documents.id),
  senderUserId: integer("sender_user_id").notNull().references(() => users.id),
  recipientDid: text("recipient_did").notNull(),
  accessLevel: text("access_level").notNull(),
  expiresAt: timestamp("expires_at"),
  message: text("message"),
  transactionHash: text("transaction_hash"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  documentId: integer("document_id").references(() => documents.id),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentShareSchema = createInsertSchema(documentShares).omit({
  id: true,
  createdAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

export type InsertDocumentShare = z.infer<typeof insertDocumentShareSchema>;
export type DocumentShare = typeof documentShares.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Document type options
export const DOCUMENT_TYPES = [
  "Legal document",
  "Financial document",
  "Health document",
  "Intellectual property",
  "Personal ID",
  "Other"
];

// Activity types
export const ACTIVITY_TYPES = {
  DOCUMENT_UPLOAD: "document_upload",
  DOCUMENT_SHARE: "document_share",
  DOCUMENT_NFT_MINT: "document_nft_mint",
  WALLET_CONNECT: "wallet_connect",
  DID_CREATE: "did_create"
};

// Access levels
export const ACCESS_LEVELS = {
  VIEW_ONLY: "view_only",
  FULL_ACCESS: "full_access"
};

// Access durations
export const ACCESS_DURATIONS = [
  "7 days",
  "30 days",
  "90 days",
  "1 year", 
  "Unlimited"
];

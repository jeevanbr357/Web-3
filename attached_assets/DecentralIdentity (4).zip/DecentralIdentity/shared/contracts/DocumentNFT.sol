// SPDX-License-Identifier: MIT
pragma solidity ^0.8.9;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/Counters.sol";

/**
 * @title DocumentNFT
 * @dev Contract for representing documents as NFTs for ownership verification
 */
contract DocumentNFT is ERC721URIStorage, ERC721Enumerable, Ownable {
    using Counters for Counters.Counter;
    Counters.Counter private _tokenIds;
    
    // Document metadata structure
    struct DocumentMetadata {
        string title;
        string documentType;
        string ipfsCid;
        uint256 createdAt;
        string[] tags;
    }
    
    // Mapping from token ID to document metadata
    mapping(uint256 => DocumentMetadata) private _documentMetadata;
    
    // Mapping from IPFS CID to token ID to ensure uniqueness
    mapping(string => uint256) private _cidToTokenId;
    
    // Events
    event DocumentMinted(uint256 indexed tokenId, address indexed owner, string ipfsCid);
    event DocumentMetadataUpdated(uint256 indexed tokenId, string title, string documentType);
    
    constructor() ERC721("SecureID Document NFT", "SDNFT") {}
    
    /**
     * @dev Mint a new document NFT
     * @param recipient The recipient who will own the NFT
     * @param tokenURI The token URI containing the metadata
     * @param title The document title
     * @param documentType The document type
     * @param ipfsCid The IPFS CID of the document
     * @param tags Optional tags for the document
     * @return The ID of the minted token
     */
    function mintDocument(
        address recipient,
        string memory tokenURI,
        string memory title,
        string memory documentType,
        string memory ipfsCid,
        string[] memory tags
    ) public onlyOwner returns (uint256) {
        require(bytes(ipfsCid).length > 0, "IPFS CID cannot be empty");
        require(_cidToTokenId[ipfsCid] == 0, "Document with this CID already exists");
        
        _tokenIds.increment();
        uint256 newTokenId = _tokenIds.current();
        
        _mint(recipient, newTokenId);
        _setTokenURI(newTokenId, tokenURI);
        
        _documentMetadata[newTokenId] = DocumentMetadata({
            title: title,
            documentType: documentType,
            ipfsCid: ipfsCid,
            createdAt: block.timestamp,
            tags: tags
        });
        
        _cidToTokenId[ipfsCid] = newTokenId;
        
        emit DocumentMinted(newTokenId, recipient, ipfsCid);
        
        return newTokenId;
    }
    
    /**
     * @dev Simplified mint function
     * @param recipient The recipient who will own the NFT
     * @param tokenURI The token URI containing the metadata
     * @return The ID of the minted token
     */
    function mintToken(
        address recipient,
        string memory tokenURI
    ) public onlyOwner returns (uint256) {
        _tokenIds.increment();
        uint256 newTokenId = _tokenIds.current();
        
        _mint(recipient, newTokenId);
        _setTokenURI(newTokenId, tokenURI);
        
        return newTokenId;
    }
    
    /**
     * @dev Update the metadata for a document NFT
     * @param tokenId The ID of the token to update
     * @param title The new document title
     * @param documentType The new document type
     * @param tags The new tags for the document
     */
    function updateDocumentMetadata(
        uint256 tokenId,
        string memory title,
        string memory documentType,
        string[] memory tags
    ) public onlyOwner {
        require(_exists(tokenId), "Token does not exist");
        
        DocumentMetadata storage metadata = _documentMetadata[tokenId];
        metadata.title = title;
        metadata.documentType = documentType;
        metadata.tags = tags;
        
        emit DocumentMetadataUpdated(tokenId, title, documentType);
    }
    
    /**
     * @dev Get the metadata for a document NFT
     * @param tokenId The ID of the token
     * @return The document metadata
     */
    function getDocumentMetadata(uint256 tokenId) public view returns (DocumentMetadata memory) {
        require(_exists(tokenId), "Token does not exist");
        return _documentMetadata[tokenId];
    }
    
    /**
     * @dev Get token ID by IPFS CID
     * @param ipfsCid The IPFS CID
     * @return The token ID (0 if not found)
     */
    function getTokenIdByCid(string memory ipfsCid) public view returns (uint256) {
        return _cidToTokenId[ipfsCid];
    }
    
    /**
     * @dev Get all token IDs owned by an address
     * @param owner The owner address
     * @return An array of token IDs
     */
    function getTokensByOwner(address owner) public view returns (uint256[] memory) {
        uint256 tokenCount = balanceOf(owner);
        uint256[] memory tokens = new uint256[](tokenCount);
        
        for (uint256 i = 0; i < tokenCount; i++) {
            tokens[i] = tokenOfOwnerByIndex(owner, i);
        }
        
        return tokens;
    }
    
    /**
     * @dev Required override for inherited contracts
     */
    function _beforeTokenTransfer(
        address from,
        address to,
        uint256 tokenId,
        uint256 batchSize
    ) internal override(ERC721, ERC721Enumerable) {
        super._beforeTokenTransfer(from, to, tokenId, batchSize);
    }
    
    /**
     * @dev Required override for inherited contracts
     */
    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(ERC721, ERC721Enumerable)
        returns (bool)
    {
        return super.supportsInterface(interfaceId);
    }
    
    /**
     * @dev Burn a token and remove its metadata
     * @param tokenId The ID of the token to burn
     */
    function burn(uint256 tokenId) public {
        require(_isApprovedOrOwner(_msgSender(), tokenId), "Caller is not owner nor approved");
        
        string memory ipfsCid = _documentMetadata[tokenId].ipfsCid;
        if (bytes(ipfsCid).length > 0) {
            delete _cidToTokenId[ipfsCid];
        }
        
        delete _documentMetadata[tokenId];
        _burn(tokenId);
    }
    
    /**
     * @dev Required override for inherited contracts
     */
    function _burn(uint256 tokenId) internal override(ERC721, ERC721URIStorage) {
        super._burn(tokenId);
    }
    
    /**
     * @dev Required override for inherited contracts
     */
    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721, ERC721URIStorage)
        returns (string memory)
    {
        return super.tokenURI(tokenId);
    }
}

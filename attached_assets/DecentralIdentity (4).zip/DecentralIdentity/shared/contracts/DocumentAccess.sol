// SPDX-License-Identifier: MIT
pragma solidity ^0.8.9;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

/**
 * @title DocumentAccess
 * @dev Contract for managing document access control
 */
contract DocumentAccess is Ownable, ReentrancyGuard {
    // Access level enumeration
    enum AccessLevel { VIEW_ONLY, FULL_ACCESS }
    
    // Structure to store access information
    struct Access {
        bool hasAccess;
        AccessLevel level;
        uint256 expirationTime; // 0 means no expiration
        bool isActive;
    }
    
    // Mapping from document ID to recipient DID to access details
    mapping(string => mapping(string => Access)) private accessRegistry;
    
    // List of all documents and recipients for enumeration
    string[] private documentIds;
    mapping(string => string[]) private recipientsByDocument;
    
    // Events
    event AccessGranted(string documentId, string recipientDid, AccessLevel level, uint256 expirationTime);
    event AccessRevoked(string documentId, string recipientDid);
    event AccessUpdated(string documentId, string recipientDid, AccessLevel level, uint256 expirationTime);
    
    /**
     * @dev Grant access to a document for a recipient
     * @param documentId The document identifier
     * @param recipientDid The recipient's DID
     * @param level The access level to grant
     * @param expirationTime When the access expires (0 for no expiration)
     */
    function grantAccess(
        string memory documentId,
        string memory recipientDid,
        AccessLevel level,
        uint256 expirationTime
    ) external onlyOwner nonReentrant {
        // Check if document ID exists in our registry
        bool documentExists = false;
        for (uint i = 0; i < documentIds.length; i++) {
            if (keccak256(bytes(documentIds[i])) == keccak256(bytes(documentId))) {
                documentExists = true;
                break;
            }
        }
        
        // If document doesn't exist yet, add it to our list
        if (!documentExists) {
            documentIds.push(documentId);
        }
        
        // Check if this recipient already has access to this document
        bool recipientExists = false;
        for (uint i = 0; i < recipientsByDocument[documentId].length; i++) {
            if (keccak256(bytes(recipientsByDocument[documentId][i])) == keccak256(bytes(recipientDid))) {
                recipientExists = true;
                break;
            }
        }
        
        // If recipient doesn't have access yet, add them to our list
        if (!recipientExists) {
            recipientsByDocument[documentId].push(recipientDid);
        }
        
        // Set the access details
        accessRegistry[documentId][recipientDid] = Access({
            hasAccess: true,
            level: level,
            expirationTime: expirationTime,
            isActive: true
        });
        
        emit AccessGranted(documentId, recipientDid, level, expirationTime);
    }
    
    /**
     * @dev Revoke access to a document for a recipient
     * @param documentId The document identifier
     * @param recipientDid The recipient's DID
     */
    function revokeAccess(
        string memory documentId,
        string memory recipientDid
    ) external onlyOwner nonReentrant {
        require(accessRegistry[documentId][recipientDid].hasAccess, "No access to revoke");
        
        // Deactivate access
        accessRegistry[documentId][recipientDid].isActive = false;
        
        emit AccessRevoked(documentId, recipientDid);
    }
    
    /**
     * @dev Update access details for a document and recipient
     * @param documentId The document identifier
     * @param recipientDid The recipient's DID
     * @param level The new access level
     * @param expirationTime The new expiration time
     */
    function updateAccess(
        string memory documentId,
        string memory recipientDid,
        AccessLevel level,
        uint256 expirationTime
    ) external onlyOwner nonReentrant {
        require(accessRegistry[documentId][recipientDid].hasAccess, "No access to update");
        
        // Update access details
        accessRegistry[documentId][recipientDid].level = level;
        accessRegistry[documentId][recipientDid].expirationTime = expirationTime;
        accessRegistry[documentId][recipientDid].isActive = true;
        
        emit AccessUpdated(documentId, recipientDid, level, expirationTime);
    }
    
    /**
     * @dev Check if a recipient has access to a document
     * @param documentId The document identifier
     * @param recipientDid The recipient's DID
     * @return hasAccess Whether the recipient has access
     * @return level The access level
     * @return expirationTime When the access expires (0 for no expiration)
     */
    function checkAccess(
        string memory documentId,
        string memory recipientDid
    ) external view returns (bool hasAccess, AccessLevel level, uint256 expirationTime) {
        Access memory access = accessRegistry[documentId][recipientDid];
        
        // Check if access is active and not expired
        if (access.isActive) {
            if (access.expirationTime == 0 || access.expirationTime > block.timestamp) {
                return (true, access.level, access.expirationTime);
            }
        }
        
        return (false, AccessLevel.VIEW_ONLY, 0);
    }
    
    /**
     * @dev Get all recipients who have access to a document
     * @param documentId The document identifier
     * @return recipients Array of recipient DIDs
     */
    function getRecipients(string memory documentId) external view returns (string[] memory) {
        return recipientsByDocument[documentId];
    }
    
    /**
     * @dev Get all documents that have access controls
     * @return documents Array of document IDs
     */
    function getDocuments() external view returns (string[] memory) {
        return documentIds;
    }
    
    /**
     * @dev Check if a document exists in the registry
     * @param documentId The document identifier
     * @return exists Whether the document exists
     */
    function documentExists(string memory documentId) external view returns (bool) {
        for (uint i = 0; i < documentIds.length; i++) {
            if (keccak256(bytes(documentIds[i])) == keccak256(bytes(documentId))) {
                return true;
            }
        }
        return false;
    }
}

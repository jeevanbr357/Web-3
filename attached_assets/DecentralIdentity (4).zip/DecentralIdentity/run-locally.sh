#!/bin/bash

echo "Decentralized Identity Project - Local Development"

echo "Checking Node.js version..."
node -v

echo ""
echo "Choose an option:"
echo "1. Run with Node.js v18 (Recommended - requires Node v18 installed)"
echo "2. Run backend only (compatible with Node.js v22)"
echo "3. Run frontend only"
echo "4. Exit"
echo ""

read -p "Enter option (1-4): " option

if [ "$option" = "1" ]; then
    echo "Running with Node.js v18..."
    echo "Make sure you have Node.js v18 installed and active"
    npm install
    npm run dev
elif [ "$option" = "2" ]; then
    echo "Running backend only..."
    npx ts-node server/local.ts
elif [ "$option" = "3" ]; then
    echo "Running frontend only..."
    node client.js
elif [ "$option" = "4" ]; then
    echo "Exiting..."
    exit 0
else
    echo "Invalid option. Please try again."
    exit 1
fi